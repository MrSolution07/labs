import React from "react";

const Db = React.createContext();
export default Db;