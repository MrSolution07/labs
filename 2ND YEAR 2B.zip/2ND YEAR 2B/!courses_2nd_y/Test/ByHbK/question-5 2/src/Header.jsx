import React, { useContext } from "react";
import Db from "./Db";
const Header = () => {
  const { color, setColor } = useContext(Db);

  const handleChange = (e) => {
    const [primary, secondary] = e.target.value.split("-");
    setColor({ primary: primary, secondary: secondary });
  };

  return (
    <div style={{ background: color.primary }} className="header">
      <label for="colors">Choose a color:</label>
      <select onChange={(e) => handleChange(e)} id="colors" name="colors">
        <option value="blue-white">Blue-White</option>
        <option value="purple-red">Purple-red</option>
        <option value="red-yellow">Red-yellow</option>
        <option value="green-brown">Green-brown</option>
      </select>
    </div>
  );
};
export default Header;
