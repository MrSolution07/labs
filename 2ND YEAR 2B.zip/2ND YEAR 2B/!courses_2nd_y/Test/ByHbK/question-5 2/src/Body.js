import React, { useContext } from "react";
import Db from "./Db";
const Body = () => {
  const { color } = useContext(Db);
  console.log(color);

  return (
    <div className="body">
      <div className="buttons">
        <button style={{ background: color.primary }}>Edit</button>
        <button style={{ background: color.secondary }}>Delete</button>
        <button style={{ background: color.primary }}>Change Password</button>
      </div>
      <div className="info">
        <p>
          <span>Login name :</span>
          <span> Doe76</span>
        </p>
        <p>
          <span>First name :</span>
          <span> Jane</span>
        </p>
        <p>
          <span>Last name :</span> <span>Doe</span>
        </p>
        <p>
          <span>Email :</span> <span>Jane@Doe.com</span>
        </p>
      </div>
    </div>
  );
};
export default Body;
