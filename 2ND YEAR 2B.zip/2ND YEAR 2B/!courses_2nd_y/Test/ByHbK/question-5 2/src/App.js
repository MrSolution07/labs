import "./styles.css";
import React, { useState } from "react";
import Body from "./Body";
import Header from "./Header";
import Db from "./Db";
// const Db = React.createContext();
export default function App() {
  const [color, setColor] = useState({ primary: "blue", secondary: "white" });
  const value = { color, setColor };
  return (
    <Db.Provider value={value}>
      <div className="App">
        <Header />
        <Body />
      </div>
    </Db.Provider>
  );
}
