import "./styles.css";
import React, { useEffect, useState } from "react";

const someCaluclatesValue = (functionName) => {
  console.log(`I'm called from ${functionName}`);
};

const Ordinaryfunction = () => {
  var [count, setCount] = useState(5);
  const [color, setColor] = useState("white");

  return (
    <div style={{ background: color }} className="cont">
      <div className="ord">My Ordunaryfunction, count is {count}</div>
      <button
        onClick={() => {
          setColor("Orange");
          setCount(count++);
          someCaluclatesValue("ordinaryfunction");
        }}
      >
        Update
      </button>
      <button onClick={() => setCount(5)}>Reset</button>
    </div>
  );
};
const Crazyfuntcion = () => {
  var [count, setCount] = useState(5);
  const [color, setColor] = useState("white");
  return (
    <div style={{ background: color }} className="cont">
      {" "}
      <div className="crz">My crazyfuntcion, count is {count}</div>
      <button
        onClick={() => {
          setColor("Orange");
          setCount(count++);
          someCaluclatesValue("crazyfuntcion");
        }}
      >
        Update
      </button>
      <button onClick={() => setCount(5)}>Reset</button>
    </div>
  );
};
export default function App() {
  return (
    <div className="App">
      <Ordinaryfunction />
      <Crazyfuntcion />
    </div>
  );
}
