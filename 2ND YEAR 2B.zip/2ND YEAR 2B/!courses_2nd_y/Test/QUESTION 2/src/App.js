import "./Design.css";
import React, { useEffect, useState } from "react";
// Importing the icons
import {GrPowerReset} from 'react-icons/gr';
import {GrUpdate} from 'react-icons/gr';

const someCaluclatesValue = (functionName) => {
  console.log(`I'm called from ${functionName}`);
};


const Ordinaryfunction = () => {
  let [count, setCount] = useState(5);
  const [color, setColor] = useState("white");

  return (
    <div style={{ background: color }} className="cont1">
      <div className="ord">My Ordunaryfunction, count is {count}</div>
      
      <div className="btn">
        <button
        onClick={() => {
          setColor("Orange");
          setCount(count+1);
          someCaluclatesValue("ordinaryfunction");
        }}
      >
        <GrUpdate/>Update 
      </button>
      <button onClick={() => setCount(5)}><span><GrPowerReset/>  </span>Reset the Counter</button>
    </div>
    </div>
  );
};

const Crazyfuntcion = () => {
  let [count, setCount] = useState(5);
  const [color, setColor] = useState("white");

  return (
    <div style={{ background: color }} className="cont2">
      {" "}
      <div className="crz">My crazyfuntcion, count is {count}</div>
      <div className="btn">
        <button
        onClick={() => {
          setColor("Orange");
          setCount(count+1);
          someCaluclatesValue("ordinaryfunction");
        }}
      >
        <GrUpdate/>Update 
      </button>
      <button onClick={() => setCount(5)}><span><GrPowerReset/> </span>Reset the Counter</button>
    </div>
    </div>
  );
};
export default function App() {
  return (
    <div className="App">
      <Ordinaryfunction />
      <Crazyfuntcion />
    </div>
  );
}