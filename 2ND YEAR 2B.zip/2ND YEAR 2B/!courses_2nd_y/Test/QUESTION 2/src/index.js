import { StrictMode } from "react";
import ReactDOM from "react-dom";
import {ImWindows8} from "react-icons/im";

import App from "./App";

const rootElement = document.getElementById("root");
ReactDOM.render(

  
  <StrictMode>
    <center><header>
    <h1><i><b>THE COUNTER APP  <ImWindows8/></b></i></h1>
    </header>
    </center>
    <App />
  </StrictMode>,
  rootElement
);

