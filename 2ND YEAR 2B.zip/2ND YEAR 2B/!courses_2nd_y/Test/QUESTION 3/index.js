import React from 'react';
import ReactDOM from 'react-dom';
import './Design.css';
import App from './App';
import {FaUserGraduate} from 'react-icons/fa';
import {FaGraduationCap} from 'react-icons/fa';

ReactDOM.render(
  
  <React.StrictMode>
    <header>
      <center> 
        <div class="uj"><h1><i><FaUserGraduate/>Recruitment Agency: Know Your Campus.<FaGraduationCap/></i></h1></div>
      </center>
    </header>
    
    <hr></hr>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);