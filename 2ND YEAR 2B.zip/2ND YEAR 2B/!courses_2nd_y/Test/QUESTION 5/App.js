import "./Design.css";
import Db from "./Database";
import React, { useState } from "react";
import Body from "./Body";
import Header from "./H";

// const Db = React.createContext();
export default function App() {
  const [color, setColor] = useState({ primary: "blue", secondary: "white" });
  const value = { color, setColor };
  return (
    <Db.Provider value={value}>
      <div className="App">
        <Header />
        <Body />
      </div>
    </Db.Provider>
  );
}