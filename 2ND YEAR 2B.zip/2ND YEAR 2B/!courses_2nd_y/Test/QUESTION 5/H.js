import React, { useContext } from "react";
import Db from "./Database";

// import icons
import {RiPaintLine} from 'react-icons/ri';
// import {VscPaintcan} from 'react-icons/vs';
import {AiOutlineBgColors} from 'react-icons/ai';
// import Design from "./Design";

const Header = () => {
  const { color, setColor } = useContext(Db);

  const handleChange = (e) => {
    const [primary, secondary] = e.target.value.split("-");
    setColor({ primary: primary, secondary: secondary });
  };

  return (
    <div style={{ background: color.primary }} className="header">
      <label marginLeft="50%" for="colors"><AiOutlineBgColors/></label>
      <select onChange={(e) => handleChange(e)} id="colors" name="colors">
        <option value="blue-white" style={{backgroundColor:"blue", color:"white", fontWeight:"bold"}}>BW</option>
        <option value="purple-red" style={{backgroundColor:"purple", color:"red", fontWeight:"bold"}}>PR</option>
        <option value="red-yellow" style={{backgroundColor:"Red", color:"yellow", fontWeight:"bold"}}>RY</option>
        <option value="green-brown" style={{backgroundColor:"Green", color:"brown", fontWeight:"bold"}}>GB</option>
      </select>
    </div>
  );
};
export default Header;