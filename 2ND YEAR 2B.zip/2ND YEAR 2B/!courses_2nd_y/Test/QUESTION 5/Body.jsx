// Codes Start Here

import React, { useContext } from "react";
import Db from "./Database";
import {FaRegEdit} from 'react-icons/fa';
import {RiDeleteBin5Line} from 'react-icons/ri';
import {AiTwotoneSetting} from 'react-icons/ai';


const Body = () => 
{
  const { color } = useContext(Db);
  console.log(color);

  return (

    <div className="Boxer">
      {/* The Options Colors */}
      <div className="buttons">
        <button style={{ background: color.primary }}><i><FaRegEdit/>Edit</i></button>
        <button style={{ background: color.secondary }}> <i><RiDeleteBin5Line/>Delete</i></button>
        <button style={{ background: color.primary }}><i><AiTwotoneSetting/>Change Password</i></button>
      </div>
      {/* Ends buttonts */}

      {/* The Box in the Body. */}
      <div className="details">

        <p>
          <span>Login name :</span>
          <span>Rich Isra</span>
        </p>

        <p>
          <span>First name :</span>
          <span> Israel</span>
        </p>

        <p>
          <span>Last name :</span> <span>RichDad</span>
        </p>

        <p>
          <span>Email :</span> <span>RichDad@irm.com</span>
        </p>

      </div>
      {/* End of the Boxe in the body*/}
      
    </div>
  );
};
export default Body;
      // Codes End Here