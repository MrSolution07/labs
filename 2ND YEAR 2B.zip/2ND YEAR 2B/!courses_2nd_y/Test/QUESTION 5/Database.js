import React from "react";

const Database = React.createContext();
export default Database;