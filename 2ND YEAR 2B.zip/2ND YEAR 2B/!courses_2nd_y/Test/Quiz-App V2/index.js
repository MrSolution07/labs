import Quiz from './Quiz';

export {
    Quiz
}