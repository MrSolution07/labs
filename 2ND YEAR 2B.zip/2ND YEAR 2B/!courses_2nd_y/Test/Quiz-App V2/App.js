import React from 'react';
import { Quiz } from '.';

const App = () => {

  return (
    <Quiz />
  );
};


export default App;
