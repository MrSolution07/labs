import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import {FcCustomerSupport} from 'react-icons/fc';

ReactDOM.render(

  <React.StrictMode>

    <header>
      <center> 
        <div class="uj"><h1><i><FcCustomerSupport/>Customer Information.</i></h1></div>
      </center>
  </header>

    <App />
  </React.StrictMode>,
  document.getElementById('root')
);