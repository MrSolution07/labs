import "./Design.css";
import React, { useState } from "react";
import {AiFillBank} from 'react-icons/ai'

const ClientData = ({
  AccountName, AccountType, fN, lN, date, Idnumber, MobileNo, Gender, BankName,
  BankCode, AccountNumber,
}) =>

{

  String.prototype.replaceAt = function(index, replacement) 
  {
    return this.substr(0, index) + replacement + this.substr(index + replacement.length);
  }


  let newAccNumber=(AccountNumber.replaceAt(4, "****"));

    return (
    <div className="display">
      
      <div className="Submited">
        <p>First name : {fN}</p>
        <p>Last Name : {lN}</p>
        <p>Birth Date : {date}</p>
        <p>Id Number : {Idnumber}</p>
        <p>Mobile Number : {MobileNo}</p>
        <p>Gender : {Gender}</p>
      </div>

      <div>
        <p>Bank Name : {BankName}</p>
        <p>Bank Code : {BankCode}</p>
        <p>Account Number : {newAccNumber}</p>
        <p>Account Name : {AccountName}</p>
        <p>Account Type : {AccountType}</p>
      </div>

    </div>
  );
};

function App() 
{
  const [client, setClient] = useState([]);
  const [fN, setFirstN] = useState("");
  const [lN, setLastN] = useState("");
  const [date, setDate] = useState("");
  const [Idnumber, setIdNumber] = useState("");
  const [MobileNo, setMobileNo] = useState("");
  const [Gender, setGender] = useState("Male");
  const [BankName, setBankName] = useState("");
  const [BankCode, setBankCode] = useState("");
  const [AccountNumber, setAccountNumber] = useState("");
  const [AccountName, setAccountName] = useState("");
  const [AccountType, setAccountType] = useState("");

  const submission = (event) => {
    event.preventDefault();
    const new_client = {
      fN: fN,
      lN: lN,
      date: date,
      Idnumber: Idnumber,
      MobileNo: MobileNo,
      Gender: Gender,
      BankName: BankName,
      BankCode: BankCode,
      AccountNumber: AccountNumber,
      AccountName: AccountName,
      AccountType: AccountType,
    };

    setClient([new_client, ...client]);
  };

  return (
    <React.Fragment>
      <div className="App">

      
        <form onSubmit={submission}>
        
          <div><h2>Customer Details:</h2>
          
          <input placeholder="Enter your First name" required
            onChange={(e) => setFirstN(e.target.value)} />
          
          <input placeholder="Enter your Last name" required
            onChange={(e) => setLastN(e.target.value)} />
          
          <br />

          <label>Select your Date of birth </label> 
          
          <br />
          
          <input type="date" required
          onChange={(e) => setDate(e.target.value)}/>

          <input type="number" placeholder="Enter your ID number" required
          onChange={(e) => setIdNumber(e.target.value)} />{" "}
          
          <br />
          <input type="number" placeholder="Enter your Mobile number" required
          onChange={(e) => setMobileNo(e.target.value)} />{" "}

          <br />

          <label>Gender</label>
          
          <br />

          <select onChange={(e) => setGender(e.target.value)}>
            <option>Male</option>
            <option>Female</option>
          </select></div>

          <div>
            <h2>Banking information<AiFillBank/></h2>
            <br />

          <label>Select Bank name</label>
          <select required onChange={(e) => setBankName(e.target.value)}>
          <option>Fnb</option>
            <option>NedBank</option>
            <option>Absa</option>
            <option>Capitec</option>
            <option>Standard Bank</option>
          </select> 

          <input type="number" required onChange={(e) => setBankCode(e.target.value)}
          placeholder="Type Bank code" minLength='5' maxLength="5" />{" "}
          
          <br />

          <input type="number"  required onChange={(e) => setAccountNumber(e.target.value)} placeholder="Type your Account number"
            maxLength="11"  minLength="11"/>

          <br></br>
          <br></br>
          
          <input required onChange={(e) => setAccountName(e.target.value)}
          placeholder="Type Holder Name">
          </input>

          <br></br>
          
          <br /> 


          <label>Account Type</label>
          <select placeholder=" Select Account Type" required 
          onChange={(e) => setAccountType(e.target.value)}>
            <option>Savings</option>
            <option>Checque</option>
            <option>Credit</option>
          </select>

          <br></br>
          <br></br>
          <button>Submit</button>
          </div>

          
        
          </form> 
        

        
        {client.map((customer) => (
          
          <div className="Result">
            <div>
          <ClientData
            fN={customer.fN}
            lN={customer.lN}
            date={customer.date}
            Idnumber={customer.Idnumber}
            MobileNo={customer.MobileNo}
            Gender={customer.Gender}
            BankName={customer.BankName}
            BankCode={customer.BankCode}
            AccountNumber={customer.AccountNumber}
            AccountType={customer.AccountType}
            AccountName={customer.AccountName}
          />
          </div>
          </div>

        ))}

      </div>
        
      

    </React.Fragment>
  );
}

export default App;
