import React, { useState} from 'react';
import { StyleSheet, Text, View , ScrollView, FlatList, TouchableOpacity } from 'react-native';

export default function App() {
  const [todos,setTodos] = useState([
    {name:'Randy', key:'1'},
    {name:'Sipho', key:'2'},
    {name:'Saneh', key:'3'},
    {name:'Nkazi', key:'4'},
    {name:'Siba', key:'5'},
    {name:'Cynthia', key:'6'},
    {name:'Zee', key:'7'},
    {name:'shaun', key:'88'},
    {name:'yoshi', key:'9'},
    {name:'mario', key:'10'},
    {name:'luigi', key:'11'},
    {name:'peach', key:'12'},
    {name:'toad', key:'13'},
    {name:'bowser', key:'14'},

  ]);
  return (
    <View style={styles.container}>
      <Text>To Do List</Text>
    {/* header */}
    <View style={styles.content}> 
    <View style={styles.list}>
      <FlatList
      data{todos}

      
      
      
      />

    </View>

    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  
  },
  
});
