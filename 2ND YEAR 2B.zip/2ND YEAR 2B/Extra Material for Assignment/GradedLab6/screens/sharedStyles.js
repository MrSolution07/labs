import { StyleSheet } from 'react-native';

const sharedStyles = StyleSheet.create({
    container: {
      padding: 20,
      backgroundColor: '#f9f9f9',
      flex: 1,
      justifyContent: 'center',
    },
    label: {
      fontSize: 18,
      marginBottom: 8,
      fontWeight: '600',
      color: '#555',
    },
    input: {
      backgroundColor: '#fff',
      padding: 10,
      borderRadius: 8,
      borderColor: '#ccc',
      borderWidth: 1,
      marginBottom: 16,
    },
    multilineInput: {
      height: 100,
      textAlignVertical: 'top',
    },
    colorOptions: {
      flexDirection: 'row',
      marginBottom: 16,
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    colorCircle: {
      width: 40,
      height: 40,
      borderRadius: 20,
      margin: 5,
      borderWidth: 2,
      borderColor: '#f9f9f9',
    },
    selectedColor: {
      borderColor: '#000',
    },
    addButton: {
      backgroundColor: 'black',
      padding: 16,
      borderRadius: 8,
      justifyContent: 'center',
      alignItems: 'center',
    },
    addButtonText: {
      color: '#fff',
      fontSize: 18,
      fontWeight: 'bold',
    },
    loaderContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
  });

  export default sharedStyles;