import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet} from 'react-native';
import React, { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../FirebaseConfig/firebase';
import sharedStyles from './sharedStyles';

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  const handleSignIn = () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password.');
      return;
    }

    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        Alert.alert('Success', 'You have successfully signed in!');
        navigation.navigate('Home');
      })
      .catch((error) => {
        const errorMessage = error.message;
        setError(errorMessage);
        Alert.alert('Login Error', errorMessage);
      });
  };

  return (
    <View style={sharedStyles.container}>
      <Text style={sharedStyles.label}>Email</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter email"
        keyboardType="email-address"
        // value={email}
        onChangeText={setEmail}
      />

      <Text style={sharedStyles.label}>Password</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter password"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />

      {error && <Text style={styles.errorText}>{error}</Text>}

      <TouchableOpacity style={styles.button} onPress={handleSignIn}>
        <Text style={sharedStyles.addButtonText}>Sign In</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.createAccountText}>Create an account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  errorText: {
    color: 'red',
    marginBottom: 10,
  },
  createAccountText: {
    marginTop: 16,
    color: '#555',
    textAlign: 'center',
  },
  button: {
    backgroundColor: 'black',
    padding: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
