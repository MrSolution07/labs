import { View, Text, TouchableOpacity, Image, ScrollView, Alert, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import React, { useState } from 'react';
import { auth, db } from '../FirebaseConfig/firebase';
import { collection, getDocs, updateDoc, deleteDoc, doc, query, where, getDoc } from 'firebase/firestore';

export default function HomeScreen({ navigation }) {
  const [cards, setCards] = useState([]);
  const [firstName, setfirstName] = useState('');
  const [ lastName, setLastName] = useState('');
  const flashcardsCollectionRef = collection(db, "flashcards");
  const currentUser = auth.currentUser;

  useFocusEffect(
    React.useCallback(() => {
      const fetchCards = async () => {
        if (currentUser) {
          const q = query(flashcardsCollectionRef, where("uid", "==", currentUser.uid));
          const data = await getDocs(q);
          setCards(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
        }
      };

      const fetchUsername = async () => {
        if (currentUser) {
          const userDoc = doc(db, "users", currentUser.uid);
          const userData = await getDoc(userDoc);
          setfirstName(userData.data()?.firstName || 'User');
          setLastName(userData.data()?.lastName || 'User'); 
        }
      };

      fetchCards();
      fetchUsername();
    }, [currentUser])
  );

  const markAsComplete = async (id) => {
    const cardDoc = doc(db, "flashcards", id);
    await updateDoc(cardDoc, { status: 'completed' });
    setCards((prev) => prev.map(card => card.id === id ? { ...card, status: 'completed' } : card));
  };

  const deleteCard = async (id) => {
    const cardDoc = doc(db, "flashcards", id);
    await deleteDoc(cardDoc);
    setCards((prev) => prev.filter(card => card.id !== id));
    Alert.alert("FlashCard deleted successfully");
  };

  const incompleteCards = cards.filter(card => card.status !== 'completed');
  const completedCards = cards.filter(card => card.status === 'completed');

  const getCardStyle = (color) => ({
    ...styles.card,
    backgroundColor: color || '#fff',
  });

  return (
    <View style={styles.screenContainer}>

      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
          <Text style={styles.headerText}>Hello, <Text style={styles.usernameText}>{firstName} {lastName}</Text></Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('AddCard')}>
          <Text style={styles.addButton}>Add</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.contentContainer}>
        <Text style={styles.sectionTitle}>Incomplete Flashcards</Text>
        {incompleteCards.map((card) => (
          <TouchableOpacity key={card.id} onPress={() => navigation.navigate('EditCard', { card })}>
            <View style={getCardStyle(card.color)}>
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>{card.title}</Text>
                <Text style={styles.cardDate}>{card.due_date}</Text>
                <Text style={styles.cardTasks}>{card.tasks}</Text>
              </View>
              <View style={styles.cardActions}>
                <TouchableOpacity style={styles.actionButton} onPress={() => deleteCard(card.id)}>
                  <Image
                    source={{ uri: 'https://thumbs.dreamstime.com/b/bin-delete-remove-icon-signs-symbols-can-be-used-web-logo-mobile-app-ui-ux-white-background-140234983.jpg' }}
                    style={styles.deleteIcon}
                  />
                  <Text style={styles.actionText}>Delete</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={() => markAsComplete(card.id)}>
                  <Text style={styles.actionText}>Mark as Complete</Text>
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        ))}

        <Text style={styles.sectionTitle}>Completed Flashcards</Text>
        {completedCards.map((card) => (
          <View key={card.id} style={getCardStyle(card.color)}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{card.title}</Text>
              <Text style={styles.cardDate}>{card.due_date}</Text>
              <Text style={styles.cardTasks}>{card.tasks}</Text>
            </View>
            <View style={styles.cardActions}>
              <Text style={styles.completedText}>Completed</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  headerContainer: {
    backgroundColor: '#ffffff',
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderColor: '#ddd',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  usernameText: {
    color: 'blue',
  },
  addButton: {
    fontSize: 18,
    color: 'green',
    fontWeight: 'bold',
  },
  contentContainer: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
  },
  card: {
    padding: 16,
    borderRadius: 10,
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  cardContent: {
    marginBottom: 10,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '600',
  },
  cardDate: {
    fontSize: 14,
    color: '#888',
  },
  cardTasks: {
    fontSize: 16,
    marginTop: 8,
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  deleteIcon: {
    width: 20,
    height: 20,
    marginRight: 8,
  },
  actionText: {
    color: 'red',
  },
  completedText: {
    color: 'green',
    fontWeight: 'bold',
  },
});
