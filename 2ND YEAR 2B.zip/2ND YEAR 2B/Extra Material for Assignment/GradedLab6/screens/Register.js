import { View, Text, TextInput, Alert,StyleSheet } from 'react-native';
import React, { useState } from 'react';
import { TouchableOpacity } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore'; 
import { auth, db } from '../FirebaseConfig/firebase'; 
import sharedStyles from './sharedStyles';  

export default function Register({ navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPass] = useState('');

  const handleSignUp = () => {
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }
    if(password.length < 8){
      Alert.alert('Error', 'Password must be at least 8 characters');
      return;
    }

    createUserWithEmailAndPassword(auth, email, password)
      .then(async (userCredential) => {
        const user = userCredential.user;
        try {
          await setDoc(doc(db, 'users', user.uid), {
            firstName: firstName,
            lastName: lastName,
            email: user.email,
            uid: user.uid,
          });

          Alert.alert('Success', `Welcome ${firstName} ${lastName}!`);
          navigation.navigate('Login');
        } catch (error) {
          console.log('Error adding user to Firestore: ', error);
          Alert.alert('Firestore Error', 'Failed to save user info.');
        }
      })
      .catch((error) => {
        const errorMessage = error.message;
        Alert.alert('Sign Up Error', errorMessage);
      });
  };

  return (
    <View style={sharedStyles.container}>
      <Text style={sharedStyles.label}>First Name</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter first name"
        value={firstName}
        onChangeText={setFirstName}
      />

      <Text style={sharedStyles.label}>Last Name</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter last name"
        value={lastName}
        onChangeText={setLastName}
      />

      <Text style={sharedStyles.label}>Email</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter email"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <Text style={sharedStyles.label}>Password</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Enter password"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />

      <Text style={sharedStyles.label}>Confirm Password</Text>
      <TextInput
        style={sharedStyles.input}
        placeholder="Re-enter password"
        secureTextEntry={true}
        value={confirmPassword}
        onChangeText={setConfirmPass}
      />

      <TouchableOpacity style={styles.button} onPress={handleSignUp}>
        <Text style={sharedStyles.addButtonText}>Sign Up</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.signInText}>Already have an account? Sign In</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  signInText: {
    marginTop: 20,
    color: '#007bff',
    fontSize: 16,
    textAlign: 'center',
  },
  button: {
    backgroundColor: 'black',
    padding: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
