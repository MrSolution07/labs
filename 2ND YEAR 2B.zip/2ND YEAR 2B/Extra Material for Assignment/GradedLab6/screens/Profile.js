import { View, Text, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import React, { useState, useEffect } from 'react';
import { signOut, deleteUser } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore'; 
import { db, auth } from '../FirebaseConfig/firebase'; 

export default function Profile({ navigation }) {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  const user = auth.currentUser;

  useEffect(() => {
    const fetchUserData = async () => {
      if (user) {
        try {
          const userDoc = doc(db, 'users', user.uid); 
          const docSnapshot = await getDoc(userDoc);
          if (docSnapshot.exists()) {
            setUserData(docSnapshot.data());
          } else {
            console.log('No such document!');
          }
        } catch (error) {
          console.log('Error fetching user data:', error);
        }
      }
      setLoading(false);
    };

    fetchUserData();
  }, [user]);

  const handleSignOut = () => {
    Alert.alert(
      'Confirm Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          onPress: () => {
            setLoading(true); 
            signOut(auth)
              .then(() => {
                Alert.alert('Signed Out', 'You have been signed out successfully.');
                navigation.navigate('Login');
                navigation.reset({
                  index: 0,
                  routes: [{ name: 'Login' }],
                  
                });
              })
              
              .catch((error) => {
                Alert.alert('Sign Out Error', error.message);
              })
              .finally(() => {
                setLoading(false);
              });
          },
        },
      ],
      { cancelable: false }
    );
  };

  const handleDelete = () => {
    if (user) {
      Alert.alert('Confirm Delete', 'Are you sure you want to delete your account?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          onPress: () => {
            deleteUser(user)
              .then(() => {
              Alert.alert('Delete', 'account deleted successfully.');
              navigation.navigate('Login');
              navigation.reset({
                index: 0,
                routes: [{ name: 'Login' }],
                
                });
              })
              .catch((error) => {
                Alert.alert('Delete Account Error', error.message);
              });
          },
        },
      ]);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>

      {userData && (
        <View style={styles.userInfoContainer}>
          <Text style={styles.label}>First Name:</Text>
          <Text style={styles.userInfoText}>{userData.firstName}</Text>

          <Text style={styles.label}>Last Name:</Text>
          <Text style={styles.userInfoText}>{userData.lastName}</Text>

          <Text style={styles.label}>Email:</Text>
          <Text style={styles.userInfoText}>{user.email}</Text>

          <Text style={styles.label}>UserID:</Text>
          <Text style={styles.userInfoText}>{user.uid}</Text>
        </View>
      )}

      <TouchableOpacity style={styles.button} onPress={handleSignOut}>
        <Text style={styles.buttonText}>Sign Out</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.deleteButton]} onPress={handleDelete}>
        <Text style={styles.buttonText}>Delete Account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  userInfoContainer: {
    marginBottom: 30,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#555',
    marginBottom: 5,
  },
  userInfoText: {
    fontSize: 18,
    color: '#333',
    marginBottom: 15,
  },
  button: {
    backgroundColor: 'black',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: '600',
  },
  deleteButton: {
    backgroundColor: '#ff4d4d',
  },
});
