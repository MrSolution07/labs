import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert,StyleSheet } from 'react-native';
import React, { useState } from 'react';
import { db, auth } from '../FirebaseConfig/firebase';
import { addDoc, collection } from 'firebase/firestore';
import sharedStyles from './sharedStyles';

export default function Add({ navigation }) {
  const [title, setTitle] = useState("");
  const [tasks, setTasks] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [selectedColor, setSelectedColor] = useState("#ffadad");

  const flashcardsCollectionRef = collection(db, "flashcards");

  const createFlashcard = async () => {
    if (title.trim() === "" || tasks.trim() === "" || dueDate.trim() === "") {
      Alert.alert("All fields are required!");
      return;
    }

    try {
      const currentUser = auth.currentUser; 
      if (currentUser) {
        await addDoc(flashcardsCollectionRef, {
          title,
          tasks,
          due_date: dueDate,
          color: selectedColor,
          status: 'incomplete',
          uid: currentUser.uid,
        });

        Alert.alert("Flashcard added successfully!");
        navigation.goBack();
      } else {
        Alert.alert("You need to be signed in to add a flashcard.");
      }
    } catch (error) {
      Alert.alert("Error adding flashcard:", error.message);
    }
  };

  const colorOptions = ['#FFB3BA', '#FFC3A0', '#BAE1FF', '#A0D99E', '#FF677D'];

  return (
    <ScrollView contentContainerStyle={sharedStyles.container}>
      <View style={styles.formContainer}>
        <Text style={sharedStyles.label}>Title</Text>
        <TextInput
          style={sharedStyles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="Enter flashcard title"
          placeholderTextColor="#999"
        />

        <Text style={sharedStyles.label}>Tasks</Text>
        <TextInput
          style={[sharedStyles.input, sharedStyles.multilineInput]}
          value={tasks}
          onChangeText={setTasks}
          placeholder="Enter tasks"
          placeholderTextColor="#999"
          multiline
          numberOfLines={4}
        />

        <Text style={sharedStyles.label}>Due Date</Text>
        <TextInput
          style={sharedStyles.input}
          value={dueDate}
          onChangeText={setDueDate}
          placeholder="DD-MM-YYYY"
          placeholderTextColor="#999"
        />

        <Text style={sharedStyles.label}>Select Color</Text>
        <View style={sharedStyles.colorOptions}>
          {colorOptions.map((color) => (
            <TouchableOpacity
              key={color}
              style={[sharedStyles.colorCircle, { backgroundColor: color }, selectedColor === color && sharedStyles.selectedColor]}
              onPress={() => setSelectedColor(color)}
            />
          ))}
        </View>

        <TouchableOpacity style={sharedStyles.addButton} onPress={createFlashcard}>
          <Text style={sharedStyles.addButtonText}>Add Flashcard</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  formContainer: {
    flex: 1,
    paddingBottom: 20,
  },
});
