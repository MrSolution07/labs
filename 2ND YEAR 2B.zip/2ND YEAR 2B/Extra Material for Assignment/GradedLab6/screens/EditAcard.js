import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert, StyleSheet } from 'react-native';
import React, { useState } from 'react';
import { db } from '../FirebaseConfig/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import sharedStyles from './sharedStyles'; 

export default function EditScreen({ route, navigation }) {
  const { card } = route.params;
  const [title, setTitle] = useState(card.title);
  const [dueDate, setDueDate] = useState(card.due_date);
  const [tasks, setTasks] = useState(card.tasks);
  const [selectedColor, setSelectedColor] = useState(card.color || '#fff');

  const colorOptions = ['#FFB3BA', '#FFC3A0', '#BAE1FF', '#A0D99E', '#FF677D'];

  const updateCard = async () => {
    const cardDoc = doc(db, "flashcards", card.id);
    await updateDoc(cardDoc, {
      title,
      due_date: dueDate,
      tasks,
      color: selectedColor,
    });
    Alert.alert("FlashCard updated successfully");
    navigation.goBack();
  };

  return (
    <ScrollView contentContainerStyle={sharedStyles.container}>
      <View style={styles.formContainer}>
        <Text style={sharedStyles.label}>Title</Text>
        <TextInput
          style={sharedStyles.input}
          value={title}
          onChangeText={setTitle}
        />

        <Text style={sharedStyles.label}>Due Date</Text>
        <TextInput
          style={sharedStyles.input}
          value={dueDate}
          onChangeText={setDueDate}
          placeholder="YYYY-MM-DD"
        />

        <Text style={sharedStyles.label}>Tasks</Text>
        <TextInput
          style={[sharedStyles.input, sharedStyles.multilineInput]}
          value={tasks}
          onChangeText={setTasks}
          multiline
          numberOfLines={4}
        />

        <Text style={sharedStyles.label}>Select Color</Text>
        <View style={sharedStyles.colorOptions}>
          {colorOptions.map((color) => (
            <TouchableOpacity
              key={color}
              style={[
                sharedStyles.colorCircle,
                { backgroundColor: color },
                selectedColor === color && sharedStyles.selectedColor,
              ]}
              onPress={() => setSelectedColor(color)}
            />
          ))}
        </View>

        <TouchableOpacity style={sharedStyles.addButton} onPress={updateCard}>
          <Text style={sharedStyles.addButtonText}>Update</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  formContainer: {
    flex: 1,
    paddingBottom: 20,
  },
});
