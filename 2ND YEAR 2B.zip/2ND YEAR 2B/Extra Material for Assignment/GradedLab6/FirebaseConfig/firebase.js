// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"; 
import { getAuth, initializeAuth, getReactNativePersistence } from "firebase/auth";
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';
// import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// Import the functions you need from the SDKs you need
const firebaseConfig = {
  apiKey: "AIzaSyB8nXz3FdmTyLVNIhwoq94EwcTzWTulAnM",
  authDomain: "flashcard-6b99b.firebaseapp.com",
  projectId: "flashcard-6b99b",
  storageBucket: "flashcard-6b99b.appspot.com",
  messagingSenderId: "1045099549263",
  appId: "1:1045099549263:web:068aff8319638ce83b503a",
  measurementId: "G-LBDBTD4V73"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
const db = getFirestore(app); 
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});


// Export Firestore
export {auth, db };