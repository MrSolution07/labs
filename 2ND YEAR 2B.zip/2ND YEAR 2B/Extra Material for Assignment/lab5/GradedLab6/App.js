import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState(null);

  // Function to handle button presses for numbers and operators
  const handlePress = (value) => {
    setInput((prevInput) => prevInput + value);
  };

  // Function to calculate the result
  const calculateResult = () => {
    try {
      // Handle percentage calculation
      const modifiedInput = input.replace(/(\d+)%/g, (match, num) => num / 100);
      setResult(eval(modifiedInput)); // Evaluate the mathematical expression
    } catch (error) {
      setResult('Error'); // Handle any invalid inputs
    }
  };

  // Function to clear the input and result
  const clearInput = () => {
    setInput('');
    setResult(null);
  };
  const deleteLastCharacter = () => {
    setInput((prevInput) => prevInput.slice(0, -1));
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.display}>
        {result !== null ? result : input || '0'}
      </Text>
      <View style={styles.row}>
        <Button label="1" onPress={() => handlePress('1')} />
        <Button label="2" onPress={() => handlePress('2')} />
        <Button label="3" onPress={() => handlePress('3')} />
        <Button style={{backgroundColor:'orange'}} label="+" onPress={() => handlePress('+')} />
      </View>
      <View style={styles.row}>
        <Button  label="4" onPress={() => handlePress('4')} />
        <Button label="5" onPress={() => handlePress('5')} />
        <Button label="6" onPress={() => handlePress('6')} />
        <Button style={{backgroundColor:'orange'}} label="-" onPress={() => handlePress('-')} />
      </View>
      <View style={styles.row}>
        <Button  label="7" onPress={() => handlePress('7')} />
        <Button  label="8" onPress={() => handlePress('8')} />
        <Button label="9" onPress={() => handlePress('9')} />
        <Button style={{backgroundColor:'orange'}} label="*" onPress={() => handlePress('*')} />
      </View>
      <View style={styles.row}>
        <Button style={{backgroundColor:'orange'}}  label="C" onPress={clearInput} />
        <Button  label="0" onPress={() => handlePress('0')} />
        <Button style={{backgroundColor:'orange'}}  label="Del" onPress={deleteLastCharacter} />
        <Button style={{backgroundColor:'orange'}}  label="=" onPress={calculateResult} />
        <Button style={{backgroundColor:'orange'}} label="/" onPress={() => handlePress('/')} />
      </View>
      <View style={styles.row}>
        <Button label="%" onPress={() => handlePress('%')} />
        <Button label="." onPress={() => handlePress('.')} />
      </View>
    </SafeAreaView>
  );
}

// Reusable button component
const Button = ({ label, onPress, style }) => (
  <TouchableOpacity style={[styles.button, style]} onPress={onPress}>
    <Text style={styles.buttonText}>{label}</Text>
  </TouchableOpacity>
);

// Styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  display: {
    fontSize: 40,
    textAlign: 'right',
    marginBottom: 20,
    color: '#333',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    flex: 1,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'grey',
    margin: 5,
    borderRadius: 10,
  },
  buttonText: {
    fontSize: 24,
    color: '#fff',
  },
});