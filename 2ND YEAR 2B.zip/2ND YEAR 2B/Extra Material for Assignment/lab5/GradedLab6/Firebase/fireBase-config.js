// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { getAuth } from 'firebase/auth';
import { getFirestore } from "firebase/firestore";



// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAnKXEsVflhC0PQp6C5p1_2ZsGS9DvM-ao",
  authDomain: "gradedlab5-85bdf.firebaseapp.com",
  projectId: "gradedlab5-85bdf",
  storageBucket: "gradedlab5-85bdf.appspot.com",
  messagingSenderId: "159527218422",
  appId: "1:159527218422:web:b66c65356799da301490d7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);