import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import React, { useState, useEffect } from 'react';
import { auth } from '../../Firebase/fireBase-config';
import { signOut, deleteUser } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore'; 
import { db } from '../../Firebase/fireBase-config'; 

export default function Profile({ navigation }) {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  const user = auth.currentUser;

  useEffect(() => {
    const fetchUserData = async () => {
      if (user) {
        try {
          const userDoc = doc(db, 'users', user.uid); 
          const docSnapshot = await getDoc(userDoc);
          if (docSnapshot.exists()) {
            setUserData(docSnapshot.data());
          } else {
            console.log('No such document!');
          }
        } catch (error) {
          console.log('Error fetching user data:', error);
        }
      }
      setLoading(false);
    };

    fetchUserData();
  }, [user]);

  const handleSignOut = () => {
    signOut(auth)
      .then(() => {
        Alert.alert('Signed Out', 'You have been signed out successfully.');
        navigation.replace('SignIn'); 
      })
      .catch((error) => {
        Alert.alert('Sign Out Error', error.message);
      });
  };


  const handleDelete = () => {
    if (user) {
      Alert.alert('Confirm Delete', 'Are you sure you want to delete your account?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          onPress: () => {
            deleteUser(user)
              .then(() => {
                Alert.alert('Account Deleted', 'Your account has been deleted.');
                navigation.replace('SignUp'); 
              })
              .catch((error) => {
                Alert.alert('Delete Account Error', error.message);
              });
          },
        },
      ]);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>

      {userData && (
        <View style={styles.userInfoContainer}>
          <Text style={styles.label}>First Name:</Text>
          <Text style={styles.userInfoText}>{userData.firstName}</Text>

          <Text style={styles.label}>Last Name:</Text>
          <Text style={styles.userInfoText}>{userData.lastName}</Text>

          <Text style={styles.label}>Email:</Text>
          <Text style={styles.userInfoText}>{user.email}</Text>

          <Text style={styles.label}>UserID:</Text>
          <Text style={styles.userInfoText}>{user.uid}</Text>
        </View>
      )}

      <TouchableOpacity style={styles.button} onPress={handleSignOut}>
        <Text style={styles.buttonText}>Sign Out</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.deleteButton]} onPress={handleDelete}>
        <Text style={styles.buttonText}>Delete Account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  userInfoContainer: {
    marginBottom: 30,
  },
  label: {
    fontSize: 18,
    color: '#666',
    marginBottom: 5,
  },
  userInfoText: {
    fontSize: 16,
    marginBottom: 15,
    color: '#333',
  },
  button: {
    backgroundColor: '#0066cc',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#cc0000',
  },
  loadingText: {
    fontSize: 18,
    textAlign: 'center',
    color: '#333',
  },
});
