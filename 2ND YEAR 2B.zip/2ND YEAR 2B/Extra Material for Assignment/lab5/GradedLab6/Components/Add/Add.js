import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView, Image } from 'react-native';
import React, { useState } from 'react';
import { db, auth } from '../../Firebase/fireBase-config';
import { addDoc, collection } from 'firebase/firestore';

export default function Add({ navigation }) {
  const [title, setTitle] = useState("");
  const [tasks, setTasks] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [selectedColor, setSelectedColor] = useState("#ffadad");

  const flashcardsCollectionRef = collection(db, "flashcards");

  const createFlashcard = async () => {
    if (title.trim() === "" || tasks.trim() === "" || dueDate.trim() === "") {
      Alert.alert("All fields are required!");
      return;
    }

    try {
      const currentUser = auth.currentUser; 
      if (currentUser) {
        await addDoc(flashcardsCollectionRef, {
          title,
          tasks,
          due_date: dueDate,
          color: selectedColor,
          status: 'incomplete',
          uid: currentUser.uid,
        });

        Alert.alert("Flashcard added successfully!");
        navigation.goBack();
      } else {
        Alert.alert("You need to be signed in to add a flashcard.");
      }
    } catch (error) {
      Alert.alert("Error adding flashcard:", error.message);
    }
  };

  const colorOptions = ['#ffd6a5', '#fdffb6', '#caffbf', '#9bf6ff', '#a0c4ff', '#bdb2ff', '#ffc6ff'];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={require("../../assets/splash.png")} style={styles.logo} />
      </View>

      <View style={styles.formContainer}>
        <Text style={styles.label}>Title</Text>
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="Enter flashcard title"
          placeholderTextColor="#999"
        />

        <Text style={styles.label}>Tasks</Text>
        <TextInput
          style={[styles.input, styles.multilineInput]}
          value={tasks}
          onChangeText={setTasks}
          placeholder="Enter tasks"
          placeholderTextColor="#999"
          multiline
          numberOfLines={4}
        />

        <Text style={styles.label}>Due Date</Text>
        <TextInput
          style={styles.input}
          value={dueDate}
          onChangeText={setDueDate}
          placeholder="DD-MM-YYYY"
          placeholderTextColor="#999"
        />

        <Text style={styles.label}>Select Color</Text>
        <View style={styles.colorOptions}>
          {colorOptions.map((color) => (
            <TouchableOpacity
              key={color}
              style={[styles.colorCircle, { backgroundColor: color }, selectedColor === color && styles.selectedColor]}
              onPress={() => setSelectedColor(color)}
            />
          ))}
        </View>

        <TouchableOpacity style={styles.addButton} onPress={createFlashcard}>
          <Text style={styles.addButtonText}>Add Flashcard</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 24,
    paddingHorizontal: 20,
    backgroundColor: '#f9f9f9',
    flexGrow: 1,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 80,
    height: 50,
  },
  formContainer: {
    backgroundColor: '#fff',
    padding: 24,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  label: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#f4f4f4',
    padding: 14,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 16,
  },
  multilineInput: {
    height: 120,
    textAlignVertical: 'top',
  },
  colorOptions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
    marginBottom: 24,
  },
  colorCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    margin: 5,
    borderWidth: 2,
    borderColor: '#f4f4f4',
  },
  selectedColor: {
    borderColor: '#333',
  },
  addButton: {
    backgroundColor: '#007bff',
    padding: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
