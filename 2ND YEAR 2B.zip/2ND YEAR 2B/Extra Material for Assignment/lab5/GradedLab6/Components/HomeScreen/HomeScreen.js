import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { auth, db } from '../../Firebase/fireBase-config';
import { collection, getDocs, updateDoc, deleteDoc, doc, query, where, getDoc } from 'firebase/firestore';

export default function HomeScreen({ navigation }) {
  const [cards, setCards] = useState([]);
  const [username, setUsername] = useState('');
  const flashcardsCollectionRef = collection(db, "flashcards");
  
  const currentUser = auth.currentUser;

  useFocusEffect(
    React.useCallback(() => {
      const fetchCards = async () => {
        if (currentUser) {
          const q = query(flashcardsCollectionRef, where("uid", "==", currentUser.uid));
          const data = await getDocs(q);
          setCards(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
        }
      };

      const fetchUsername = async () => {
        if (currentUser) {
          const userDoc = doc(db, "users", currentUser.uid);
          const userData = await getDoc(userDoc);
          setUsername(userData.data()?.firstName || 'User');
        }
      };

      fetchCards();
      fetchUsername();
    }, [currentUser])
  );

  const markAsComplete = async (id) => {
    const cardDoc = doc(db, "flashcards", id);
    await updateDoc(cardDoc, { status: 'completed' });
    setCards((prev) => prev.map(card => card.id === id ? { ...card, status: 'completed' } : card));
  };

  const deleteCard = async (id) => {
    const cardDoc = doc(db, "flashcards", id);
    await deleteDoc(cardDoc);
    setCards((prev) => prev.filter(card => card.id !== id));
    Alert.alert("FlashCard deleted successfully");
  };

  const incompleteCards = cards.filter(card => card.status !== 'completed');
  const completedCards = cards.filter(card => card.status === 'completed');

  const getCardStyle = (color) => ({
    ...styles.card,
    backgroundColor: color || '#fff',
  });

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
          <Text style={styles.username}>Hello, {username}</Text> 
        </TouchableOpacity>
        <Image source={require("../../assets/splash.png")} style={styles.logo} />
      </View>
      
      <View style={styles.header}>
        <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('Add')}>
          <Text style={styles.addButtonText}>+</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>Incomplete Flashcards</Text>
      {incompleteCards.map((card) => (
        <TouchableOpacity key={card.id} onPress={() => navigation.navigate('EditScreen', { card })}>
          <View style={getCardStyle(card.color)}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{card.title}</Text>
              <Text style={styles.cardDate}>{card.due_date}</Text>
              <Text style={styles.cardTasks}>{card.tasks}</Text>
            </View>
            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.actionButton} onPress={() => deleteCard(card.id)}>
                <Image
                  source={{ uri: 'https://thumbs.dreamstime.com/b/bin-delete-remove-icon-signs-symbols-can-be-used-web-logo-mobile-app-ui-ux-white-background-140234983.jpg' }}
                  style={styles.deleteIcon}
                />
                <Text style={styles.actionText}>Delete</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={() => markAsComplete(card.id)}>
                <Text style={styles.actionText}>Mark as Complete</Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      ))}

      <Text style={styles.sectionTitle}>Completed Flashcards</Text>
      {completedCards.map((card) => (
        <View key={card.id} style={getCardStyle(card.color)}>
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>{card.title}</Text>
            <Text style={styles.cardDate}>{card.due_date}</Text>
            <Text style={styles.cardTasks}>{card.tasks}</Text>
          </View>
          <View style={styles.cardActions}>
            <Text style={styles.completedText}>Completed</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#f9f9f9',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  username: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  logo: {
    width: 80,
    height: 50,
  },
  header: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#007bff',
    padding: 16,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
  },
  addButtonText: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 12,
    color: '#333',
  },
  card: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderColor: '#ccc',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  cardContent: {
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#f94144',
  },
  cardDate: {
    fontSize: 14,
    color: '#888',
    marginBottom: 8,
  },
  cardTasks: {
    fontSize: 16,
    color: '#333',
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionText: {
    fontSize: 14,
    color: '#007bff',
    marginLeft: 8,
  },
  deleteIcon: {
    width: 20,
    height: 20,
  },
  completedText: {
    fontSize: 16,
    color: '#28a745',
    fontWeight: 'bold',
  },
});
