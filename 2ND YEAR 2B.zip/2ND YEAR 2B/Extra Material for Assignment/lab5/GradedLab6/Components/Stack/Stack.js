import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from '../HomeScreen/HomeScreen';
import Add from '../Add/Add';
import EditScreen from '../EditScreen/EditScreen';
import SignUp from '../SignUp/SignUp';
import SignIn from '../SignIn/SignIn';
import Profile from '../Profile/Profile';

const Stack = createStackNavigator();

export default function StackNavigator() {
  return (
    <Stack.Navigator initialRouteName='SignIn'>
      <Stack.Screen name="SignIn" component={SignIn}/>
      <Stack.Screen name="SignUp" component={SignUp}/>
      <Stack.Screen name="HomeScreen" component={HomeScreen} />
      <Stack.Screen name="Add" component={Add} />
      <Stack.Screen name="EditScreen" component={EditScreen} />
      <Stack.Screen name='Profile' component={Profile}/>
    </Stack.Navigator>
  );
}