import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './screens/Home';
import UserLogin from './screens/UserLogin';
import UserRegistration from './screens/UserRegistration';
import ForgotPassword from './screens/forgotpass';
import Upload from './screens/Upload';


const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="UserLogin">
        <Stack.Screen name="UserLogin" component={UserLogin} />
        <Stack.Screen name="UserRegistration" component={UserRegistration} />
        <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
        <Stack.Screen name="Upload" component={Upload} />
        <Stack.Screen name="Home" component={Home} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;