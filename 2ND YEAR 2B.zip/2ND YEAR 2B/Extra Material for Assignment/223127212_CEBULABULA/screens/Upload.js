import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, Image, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator'; 
import * as Location from 'expo-location';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { doc, setDoc } from 'firebase/firestore';
import { db, storage } from '../config/firebaseConfig';

export default function BusRegistration({ navigation }) {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [category, setCategory] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [logo, setLogo] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
     
      const resizedImage = await ImageManipulator.manipulateAsync(
        result.assets[0].uri,
        [{ resize: { width: 800 } }], 
        { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG } 
      );
      setLogo(resizedImage.uri);  
    }
  };

  const handleLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission denied', 'Allow location permissions to auto-fill the address.');
      return;
    }

    const location = await Location.getCurrentPositionAsync({});
    const response = await fetch(
      `https://api.opencagedata.com/geocode/v1/json?q=${location.coords.latitude}+${location.coords.longitude}&key=05e77358316e47a9b7ca4488388bbc08`
    );
    const data = await response.json();
    setLatitude(location.coords.latitude);
    setLongitude(location.coords.longitude);

    if (data.results && data.results.length > 0) {
      setAddress(data.results[0].formatted);
    } else {
      Alert.alert('Error', 'Could not retrieve address from location.');
    }
  };

  const handleSubmit = async () => {
    if (!name || !address || !category || !contactNumber || !logo) {
      Alert.alert('Error', 'Please fill all fields and upload a logo.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(logo);
      const blob = await response.blob();
      const storageRef = ref(storage, `logos/${name}_${Date.now()}`);
      await uploadBytes(storageRef, blob);
      const imageUrl = await getDownloadURL(storageRef);

      await setDoc(doc(db, 'businesses', name), {
        name,
        address,
        category,
        contactNumber,
        imageUrl,
        longitude,
        latitude,
      });

      Alert.alert('Success', 'Business registered successfully');
      navigation.navigate('Home');
    } catch (error) {
      Alert.alert('Error', 'Failed to register business');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <Text style={styles.label}>Business Name</Text>
        <TextInput style={styles.input} value={name} onChangeText={setName} />

        <Text style={styles.label}>Address</Text>
        <TextInput style={styles.input} value={address} onChangeText={setAddress} />
        <TouchableOpacity onPress={handleLocation}>
          <Text style={styles.linkText}>Use GPS location</Text>
        </TouchableOpacity>

        <Text style={styles.label}>Category</Text>
        <Picker
          selectedValue={category}
          onValueChange={(itemValue) => setCategory(itemValue)}
          style={styles.input}
        >
          <Picker.Item label="Select Category" value="" />
          <Picker.Item label="Food" value="food" />
          <Picker.Item label="Church" value="church" />
          <Picker.Item label="Bar" value="bar" />
          <Picker.Item label="Club" value="club" />
        </Picker>

        <Text style={styles.label}>Contact Number</Text>
        <TextInput style={styles.input} value={contactNumber} onChangeText={setContactNumber} keyboardType="phone-pad" />

        <TouchableOpacity onPress={pickImage} style={styles.imageButton}>
          <Text style={styles.buttonText}>Upload Logo</Text>
        </TouchableOpacity>

        {logo && (
          <Image source={{ uri: logo }} style={styles.imagePreview} />
        )}

        <TouchableOpacity onPress={handleSubmit} style={styles.submitButton}>
          {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Register Business</Text>}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#f7f9fc',
  },
  container: {
    flex: 1,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#d3d3d3',
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#fff',
    marginBottom: 15,
    fontSize: 16,
    color: '#333',
  },
  linkText: {
    color: '#007bff',
    fontSize: 14,
    marginBottom: 20,
    textAlign: 'center',
  },
  imageButton: {
    backgroundColor: '#003366',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 15,
  },
  imagePreview: {
    width: 100,
    height: 100,
    alignSelf: 'center',
    resizeMode: 'contain',
    borderWidth: 1,
    borderColor: '#d3d3d3',
    marginBottom: 15,
  },
  submitButton: {
    backgroundColor: '#003366',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
