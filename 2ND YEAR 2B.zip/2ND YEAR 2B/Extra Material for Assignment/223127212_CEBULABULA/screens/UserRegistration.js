
import React, { useState } from 'react';
import { 
  SafeAreaView, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ActivityIndicator, 
  Alert, 
  StyleSheet, 
  ScrollView 
} from 'react-native';
import { auth, createUserWithEmailAndPassword } from '../config/firebaseConfig'; 
import { db } from '../config/firebaseConfig'; 
import { doc, setDoc } from 'firebase/firestore'; 

const UserRegistration = ({ navigation }) => {
  const [firstName, setFirstName] = useState('');
  const [surname, setSurname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [passwordError, setPasswordError] = useState(null);

  // Email and password validation
  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  // Password validation
  const validatePassword = (password) => {
    const isValid = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,}$/.test(password);
    setPasswordError(
      isValid ? null : 'Password must be at least 8 characters, include uppercase, lowercase, and a special character.'
    );
    return isValid;
  };

  const handleRegister = async () => {
    setError(null);
    if (!validateEmail(email)) {
      setError('Invalid email format');
      return;
    }
    if (!validatePassword(password)) {
      setPasswordError('Password must be at least 8 characters, include uppercase, lowercase, and a special character.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const userId = userCredential.user.uid; 
      
      try {
        await setDoc(doc(db, 'users', userId), {
          firstName,
          surname,
          email,
        });
      } catch (dbError) {
        console.error("Firestore error: ", dbError); 
        setError('Failed to store user data in Firestore. Please try again.');
        return; 
      }

      Alert.alert('Success', 'Registration successful!');
      navigation.navigate('UserLogin'); 
    } catch (error) { 
      console.error("Auth error: ", error); 
      switch (error.code) {
        case 'auth/email-already-in-use': 
          setError('This email is already registered.');
          break;
        case 'auth/weak-password':
          setError('Password is too weak. Please choose a stronger password.');
          break;
        case 'auth/network-request-failed':
          setError('Network error. Please check your connection.');
          break;
        default:
          setError('Registration failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.appTitle}>Business App</Text>
        <Text style={styles.header}>User Registration</Text>
        <TextInput
          style={styles.input}
          placeholder="First Name"
          value={firstName}
          onChangeText={(text) => setFirstName(text)}
        />

        <TextInput
          style={styles.input}
          placeholder="Surname"
          value={surname}
          onChangeText={(text) => setSurname(text)}
        />

        {/* Email input */}
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={(text) => setEmail(text)}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        {error && error.includes('email') && <Text style={styles.error}>{error}</Text>}

        {/* Password input with validation */}
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            validatePassword(text);
          }}
          secureTextEntry
        />
        {passwordError && <Text style={styles.error}>{passwordError}</Text>}
        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          value={confirmPassword}
          onChangeText={(text) => setConfirmPassword(text)}
          secureTextEntry
        />
        {error && error.includes('match') && <Text style={styles.error}>{error}</Text>}

      
        <TouchableOpacity style={styles.button} onPress={handleRegister} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Register</Text>}
        </TouchableOpacity>

        {error && !error.includes('email') && !error.includes('match') && <Text style={styles.error}>{error}</Text>}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eaf0f7',
    justifyContent: 'center', 
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20,
    paddingHorizontal: 20, 
  },
  appTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginBottom: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%', 
    height: 50,
    borderColor: '#003366',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#003366',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    width: '100%', 
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  error: {
    color: '#FF5A5F',
    fontSize: 14,
    marginBottom: 10,
    textAlign: 'center',
  },
});

export default UserRegistration;