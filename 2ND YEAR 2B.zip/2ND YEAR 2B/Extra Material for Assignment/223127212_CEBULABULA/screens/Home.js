import React, { useEffect, useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  TextInput, 
  StyleSheet, 
  ActivityIndicator, 
  TouchableOpacity, 
  Image, 
  Alert 
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getAuth } from 'firebase/auth';
import { db } from '../config/firebaseConfig'; 
import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import NetInfo from '@react-native-community/netinfo';
import * as Location from 'expo-location';

const HomePage = ({ navigation }) => {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredBusinesses, setFilteredBusinesses] = useState([]);
  const [username, setUsername] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories'); 
  const [userLocation, setUserLocation] = useState(null);
  const [distanceRange, setDistanceRange] = useState(10);

  const categories = ['All Categories', 'Food', 'Bar', 'Club', 'Church'];

  useFocusEffect(
    useCallback(() => {
      const fetchData = async () => {
        setLoading(true);
        const netInfo = await NetInfo.fetch();
        if (netInfo.isConnected) {
          const auth = getAuth();
          const currentUser = auth.currentUser;

          if (currentUser) {
            const userId = currentUser.uid; 
            const userDoc = doc(db, 'users', userId);
            const userSnapshot = await getDoc(userDoc);
            if (userSnapshot.exists()) {
              const userData = userSnapshot.data();
              setUsername(userData.name); 
            } else {
              console.log('No such user!');
            }

            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status === 'granted') {
              try {
                const location = await Location.getCurrentPositionAsync({});
                setUserLocation(location.coords); 
              } catch (error) {
                console.error('Error fetching location: ', error);
                Alert.alert('Error', 'Unable to fetch location. Please try again.');
              }
            } else {
              Alert.alert('Permission Denied', 'Location permission is required to filter businesses.');
            }

            const businessesCollection = collection(db, 'businesses');
            const snapshot = await getDocs(businessesCollection);
            const businessesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setBusinesses(businessesData);
            setFilteredBusinesses(businessesData);
          } else {
            console.log('No user is currently signed in.');
          }
        } else {
          Alert.alert('No internet connection', 'Please connect to the internet and try again.');
        }
        setLoading(false);
      };

      fetchData();
    }, []) // Ensure fetchData is only redefined when dependencies change
  );

  const calculateDistance = (location1, location2) => {
    const toRad = (value) => (value * Math.PI) / 180;
    const lat1 = location1.latitude;
    const lon1 = location1.longitude;
    const lat2 = location2.latitude;
    const lon2 = location2.longitude;

    const R = 6371; 
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  useEffect(() => {
    const filterBusinesses = businesses.filter(business => {
      const matchesSearch = business.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All Categories' || business.category === selectedCategory;
      const distance = userLocation 
        ? calculateDistance(userLocation, { latitude: business.latitude, longitude: business.longitude }) 
        : Infinity;
      const matchesDistance = distance <= distanceRange;

      return matchesSearch && matchesCategory && matchesDistance;
    });
    
    setFilteredBusinesses(filterBusinesses);
  }, [searchTerm, businesses, selectedCategory, userLocation, distanceRange]);

  const renderBusinessItem = ({ item }) => (
    <View style={styles.card}>
      {item.imageUrl && (
        <Image source={{ uri: item.imageUrl }} style={styles.logo} />
      )}
      <View style={styles.infoContainer}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.category}>{item.category}</Text>
        <Text style={styles.address}>{item.address}</Text>
        <Text style={styles.contact}>{item.contactNumber}</Text>
        <Text style={styles.distanceText}>
          {userLocation ? `${calculateDistance(userLocation, { latitude: item.latitude, longitude: item.longitude }).toFixed(1)} km away` : 'Location unknown'}
        </Text>
      </View>
    </View>
  );

  const handleAddBusiness = () => {
    navigation.navigate('Upload');
  };

  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
  };

  if (loading) {
    return <ActivityIndicator size="large" color="#6200ee" style={{ flex: 1, justifyContent: 'center' }} />;
  }
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Hello {username || ''}!</Text>
        <TouchableOpacity onPress={handleAddBusiness} style={styles.addButton}>
          <Text style={styles.addButtonText}>+ Add a Business</Text>
        </TouchableOpacity>
      </View>
      <TextInput
        style={styles.searchInput}
        placeholder="Search businesses..."
        value={searchTerm}
        onChangeText={setSearchTerm}
      />
      
      {/* Filter Section */}
      <View style={styles.filterSection}>
        <Text style={styles.filterLabel}>Filter by Category:</Text>
        <View style={styles.categoryButtons}>
          {categories.map((category) => (
            <TouchableOpacity 
              key={category} 
              style={[
                styles.categoryButton, 
                selectedCategory === category && styles.selectedCategoryButton
              ]}
              onPress={() => handleCategorySelect(category)}
            >
              <Text style={[
                styles.categoryButtonText, 
                selectedCategory === category && styles.selectedCategoryButtonText
              ]}>
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
      
      {/* Distance Range Section */}
      <View style={styles.distanceSection}>
        <Text style={styles.distanceLabel}>Distance: {distanceRange} km</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.distanceButton} onPress={() => setDistanceRange((prev) => Math.max(prev - 5, 1))}>
            <Text style={styles.distanceButtonText}>-</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.distanceButton} onPress={() => setDistanceRange((prev) => prev + 5)}>
            <Text style={styles.distanceButtonText}>+</Text>
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={filteredBusinesses}
        renderItem={renderBusinessItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={<Text style={styles.noData}>No businesses found.</Text>}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eaf0f7',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
  },
  addButton: {
    backgroundColor: '#003366',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  searchInput: {
    height: 50,
    borderColor: '#003366',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  filterSection: {
    marginBottom: 16,
  },
  filterLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#003366',
    marginBottom: 8,
  },
  categoryButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  categoryButton: {
    backgroundColor: '#fff',
    borderColor: '#003366',
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginRight: 10,
    marginBottom: 10,
  },
  selectedCategoryButton: {
    backgroundColor: '#003366',
  },
  categoryButtonText: {
    color: '#003366',
    fontSize: 16,
  },
  selectedCategoryButtonText: {
    color: '#fff',
  },
  distanceSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  distanceLabel: {
    fontSize: 18,
    color: '#003366',
  },
  buttonContainer: {
    flexDirection: 'row',
  },
  distanceButton: {
    backgroundColor: '#003366',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginRight: 10,
  },
  distanceButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  listContainer: {
    paddingBottom: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
    elevation: 2,
  },
  logo: {
    width: 50,
    height: 50,
    borderRadius: 5,
    marginBottom: 10,
  },
  infoContainer: {
    marginLeft: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#003366',
  },
  category: {
    fontSize: 14,
    color: '#666',
  },
  address: {
    fontSize: 14,
    color: '#666',
  },
  contact: {
    fontSize: 14,
    color: '#666',
  },
  distanceText: {
    fontSize: 14,
    color: '#666',
  },
  noData: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 20,
    color: '#666',
  },
});

export default HomePage;
