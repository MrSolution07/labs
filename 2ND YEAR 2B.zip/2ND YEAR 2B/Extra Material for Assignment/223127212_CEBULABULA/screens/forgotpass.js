import React, { useState } from 'react';
import { TextInput, View, Text, Pressable, StyleSheet, Alert, KeyboardAvoidingView, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAuth, sendPasswordResetEmail } from 'firebase/auth'; // Import the required method from Firebase

const ForgotPassword = ({ navigation }) => {
  const [email, setEmail] = useState(''); // State for email input

  const handleResetPassword = async () => {
    if (!email) {
      Alert.alert('Error', 'Please enter an email address');
      return;
    }

    try {
      const auth = getAuth(); 
      await sendPasswordResetEmail(auth, email); 
      Alert.alert('Success', 'Password reset email sent! Please check your inbox.');
      navigation.navigate('UserLogin'); 
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
      >
        <ScrollView 
          keyboardDismissMode={Platform.OS === 'ios' ? 'interactive' :'tap'} 
          keyboardShouldPersistTaps="handled" 
          contentContainerStyle={{ flexGrow: 1 }}
        >
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ width: '100%', paddingHorizontal: 25 }}>
              <Text style={styles.header}>
                Recover your account
              </Text>
              <Text style={styles.text}>
                Fill in your email below and we will send you a link to recover your password
              </Text>
              <TextInput
                placeholder='Enter your email'
                placeholderTextColor='gray'
                value={email} 
                onChangeText={setEmail} 
                keyboardType="email-address"
                autoCapitalize="none"
                style={styles.input}
              />
              <Pressable
                style={styles.button}
                onPress={handleResetPassword} 
                android_ripple={{ color: 'lightgray' }}
              >
                <Text style={styles.buttonText}>
                  Reset Password
                </Text>
              </Pressable>

              <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 15 }}>
                <Text style={styles.linkText}>Don't have an account?{''}</Text>
                <Pressable onPress={() => navigation.navigate('Registration')}>
                  <Text style={[styles.linkText, { textDecorationLine: 'underline' }]}> Sign Up</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 25,
    justifyContent: 'center',
    backgroundColor: '#eaf0f7',
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    width: '85%',
    height: 50,
    borderColor: '#003366',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#003366',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    width: '85%',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  error: {
    color: '#FF5A5F',
    fontSize: 14,
    marginBottom: 10,
    textAlign: 'center',
  },
  linkText: {
    color: '#003366',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 15,
    textDecorationLine: 'underline',
  },
});

export default ForgotPassword;
