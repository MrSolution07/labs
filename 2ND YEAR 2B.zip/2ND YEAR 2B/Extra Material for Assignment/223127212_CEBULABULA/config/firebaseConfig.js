// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth'; // Import signInWithEmailAndPassword
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import { getStorage } from 'firebase/storage'; // Import Firebase Storage
import AsyncStorage from '@react-native-async-storage/async-storage'; 
import 'firebase/firestore';


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD91D-InIPhj7YtQcUNn1o43D2ch_YCWSA",
  authDomain: "finaltest-4928f.firebaseapp.com",
  projectId: "finaltest-4928f",
  storageBucket: "finaltest-4928f.appspot.com",
  messagingSenderId: "126089099935",
  appId: "1:126089099935:web:076e9766cb4553dea980aa",
  measurementId: "G-GV48S1CTHP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});
const db = getFirestore(app); 
const storage = getStorage(app);

// Export necessary functions and variables
export { app, auth, db, storage, createUserWithEmailAndPassword, signInWithEmailAndPassword, setDoc, doc };
