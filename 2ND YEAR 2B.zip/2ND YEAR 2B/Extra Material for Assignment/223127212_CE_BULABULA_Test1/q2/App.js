import React, { useState } from 'react';
import { View, Text, Image, TextInput, Button, Alert, ScrollView, StyleSheet, SafeAreaView } from 'react-native';

const ProfileCard = () => {
    const [isFollowed, setIsFollowed] = useState(false);

    const handleFollowToggle = () => {
      setIsFollowed(!isFollowed); 
    }

    return (
        <SafeAreaView style={styles.MainContainer}>
            <ScrollView contentContainerStyle={styles.scrollViewContent}>
                <View style={styles.card}>
                    <View style={styles.profileHeader}>
                        <Image style={styles.image} source={{ uri: 'https://reactnative.dev/img/tiny_logo.png' }} />
                        <View style={styles.textContainer}>
                            <Text style={styles.name}>John Doe</Text>
                        </View>
                    </View>
                    <TextInput style={styles.input} placeholder="Enter your bio" />
                    <TextInput style={styles.input} placeholder="Enter your profession" />
                    <View style={styles.buttonContainer}>
                        <View style={styles.buttonWrapper}>
                            <Button title="Submit" onPress={() => Alert.alert('Profile Submitted')} />
                        </View>
                        <View style={styles.buttonWrapper}>
                            <Button title={isFollowed ? "Unfollow" : "Follow"} onPress={handleFollowToggle} />
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    scrollViewContent: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    card: {
        flexDirection: 'column',
        padding: 20,
        backgroundColor: 'white',
        borderRadius: 12,
        width: '95%',
        shadowColor: 'blue',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 6,
        alignItems: 'center',
    },
    profileHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
        width: '100%',
        justifyContent: 'center',
    },
    image: {
        width: 100,
        height: 100,
        borderRadius: 100,
        marginRight: 15,
    },
    textContainer: {
        flexDirection: 'column',
        alignItems: 'center',
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    input: {
        height: 40,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        marginVertical: 5,
        borderRadius: 12,
        paddingHorizontal: 10,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
        marginTop: 20,
    },
    buttonWrapper: {
        width: '50%', 
    },
    MainContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
    }
});

export default ProfileCard;