import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CharactersComponent from './components/character/'; 
import Favorites from './components/Favorites/favorite';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/" element={<CharactersComponent />} />
      </Routes>
    </Router>
  );
};

export default App;