import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './favorites.css'; // Ensure you create this CSS file for styling

const Favorites = () => {
  const location = useLocation();
  const navigate = useNavigate(); // Use navigate to go back
  const { favorites } = location.state || { favorites: [] };
  const noUrl = 'https://st4.depositphotos.com/14953852/24787/v/380/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg'; 

  const handleBackClick = () => {navigate(-1); 
  };

  return (
    <div className="favorites-container">
      <button className="back-button" onClick={handleBackClick}>Back</button>

      <h1>Your Favorites Characters</h1>
      {favorites.length === 0 ? (
        <p>You don't have favorite characters yet!</p>
      ) : (
        <div className="character-list">
          {favorites.map(character => (
            <div key={character.id} className="character-card">
              <img 
                src={character.image || noUrl} 
                alt={character.name} 
                className="character-image" 
              />
              <h3>{character.name}</h3>
              <p>DOB: {character.dateOfBirth || 'Not specified'}</p>
              <p>Gender: {character.gender}</p>
              <p>Species: {character.species}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Favorites;