import React from 'react';
import './CharactersDetails.css';

const CharacterDetails = ({ character, onBackClick }) => {
  return (
    <div className="character-details">
      <button onClick={onBackClick} className="back-button"> Return </button>
      <img src={character.image} alt={character.name} className="character-detail-image" />
      <h2>{character.name}</h2>
      <p><strong>Date of Birth:</strong> {character.dateOfBirth}</p>
      <p><strong>Species:</strong> {character.species}</p>
      <p><strong>Gender:</strong> {character.gender}</p>
      <p><strong>House:</strong> {character.house}</p>
      <p><strong>Ancestry:</strong> {character.ancestry}</p>
      <p><strong>Eye Colour:</strong> {character.eyeColour}</p>
      <p><strong>Hair Colour:</strong> {character.hairColour}</p>
      <p><strong>Patronus:</strong> {character.patronus}</p>
    </div>
  );
};

export default CharacterDetails;
