import React, { useState, useEffect } from 'react';
import './CharactersComponents.css'; 
import CharacterDetails from '../charactersDetails';
import { useNavigate } from 'react-router-dom';
import WeatherAndTime from '../WetherAndTime';

const CharactersComponent = () => {
  const [characters, setCharacters] = useState([]);
  const [filteredCharacters, setFilteredCharacters] = useState([]);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({ gender: '', alive: '', species: '' });
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null);   
  const [favorites, setFavorites] = useState([]);
  const navigate = useNavigate(); 
  // since you want us to make the app user friendly i set a image when a character doesnt have one in the api
  const noUrl = 'https://st4.depositphotos.com/14953852/24787/v/380/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg'; 


  // Fetch  char from api here i solved the cors problem by using a solution provided on stackOverflow and can be found here link: https://stackoverflow.com/questions/43871637/no-access-control-allow-origin-header-is-present-on-the-requested-resource-whe
  // it shows an error message in case the data cant be taken and it more friendly cause it shows loadoing messages and there are errors for developers 
  useEffect(() => {
    fetch('https://warm-garden-47498-50024a4c6a66.herokuapp.com/https://hp-api.herokuapp.com/api/characters')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        setCharacters(data); 
      })
      .catch(error => {
        setError(error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  // question 1.3 and question 1.4 here to help the user filtering searches 
  useEffect(() => {
    let filtered = characters.filter(character =>
      character.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (filters.gender === '' || character.gender === filters.gender) &&
      (filters.alive === '' || (filters.alive === 'true' ? character.alive : !character.alive)) &&
      (filters.species === '' || character.species === filters.species)
    );

    setFilteredCharacters(filtered.slice(0, 9)); 
  }, [searchTerm, filters, characters]);

  const handleSearch = (event) => {setSearchTerm(event.target.value);
  };

  const handleFilterChange = (event) => {
    setFilters({...filters,[event.target.name]: event.target.value});
  };

  const handleCharacterClick = (character) => {
    setSelectedCharacter(character);
  };

  const handleBackClick = () => {
    setSelectedCharacter(null);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  const goToFavorites = () => {
    navigate('/favorites', { state: { favorites } });
  };
  const handleAddToFavorites = (character) => {
    window.alert('successfully added to favorites !');
    setFavorites(prevFavorites => [...prevFavorites, character]);
  };

  return (
    <>
    <WeatherAndTime/>
    <div className="characters-container">
      {selectedCharacter ? (
        <CharacterDetails character={selectedCharacter} onBackClick={handleBackClick} />
      ) : (
        <>
          <div className='title'>
            <h1>Harry Potter Fan Application </h1>
          </div>
          <div className="search-and-filters">
            <input 
              type="text" 
              placeholder="Search by name..." 
              value={searchTerm} 
              onChange={handleSearch} 
              className="search-bar"
            />
            <div className="filters">
              <select name="gender" value={filters.gender} onChange={handleFilterChange}>
                <option value="">All Genders</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
              <select name="alive" value={filters.alive} onChange={handleFilterChange}>
                <option value="">All Statuses</option>
                <option value="true">Alive</option>
                <option value="false">Deceased</option>
              </select>
              <select name="species" value={filters.species} onChange={handleFilterChange}>
                <option value="">All Species</option>
                <option value="human">Human</option>
                <option value="half-giant">Half-Giant</option>
                <option value="werewolf">Werewolf</option>
              </select>
            </div>
            <div className='button-fav'>
              <button className='buttonFav' onClick={goToFavorites} >
                <a>Favorite Characters</a>
              </button>
            </div>
          </div>


          <div className="character-list">
            {filteredCharacters.map(character => (
              <div 
                key={character.id} 
                className="character-card" 
               
              >
                <img  onClick={() => handleCharacterClick(character)}  src={(character.image)?character.image:noUrl} alt={character.name} className="character-image" />
                <h3 style={{fontWeight:'bold'}} onClick={() => handleCharacterClick(character)}>Know more</h3>
                <h3>{character.name}</h3>
                <p>DOB: {character.dateOfBirth || 'not specified sorry'}</p>
                <p>Species: {character.species}</p>
                <button onClick={() => handleAddToFavorites(character)} > Add To favorite</button>
              </div>
              
            ))}
            
          </div>
        </>
      )}
    </div>
    </>
  );
};

export default CharactersComponent;