import React, { useState, useEffect } from 'react';
import './style.css'; // Ensure you have this CSS file for styling

const WeatherAndTime = () => {
  const [weather, setWeather] = useState(null);
  const [time, setTime] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchWeatherAndTime = async () => {
      try {
        const weatherResponse = await fetch('https://api.open-meteo.com/v1/forecast?latitude=-26.2041&longitude=28.0473&current_weather=true');
        if (!weatherResponse.ok) {
          throw new Error(`HTTP error! Status: ${weatherResponse.status}`);
        }
        const weatherData = await weatherResponse.json();

        const timeResponse = await fetch('https://timeapi.io/api/Time/current/zone?timeZone=Africa/Johannesburg');
        if (!timeResponse.ok) {
          throw new Error(`HTTP error! Status: ${timeResponse.status}`);
        }
        const timeData = await timeResponse.json();

        setWeather(weatherData);
        setTime(timeData);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchWeatherAndTime();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div className="weather-time-container">
      <h2>Current Weather and Time in Johannesburg</h2>
      <div className="weather-info">
        <h3>Weather</h3>
        {weather ? (
          <div>
            <p>Temperature: {weather.current_weather.temperature}°C</p>
            <p>Condition: {weather.current_weather.weathercode}</p>
          </div>
        ) : (
          <p>No weather data available</p>
        )}
      </div>
      <div className="time-info">
        <h3>Time</h3>
        {time ? (
          <div>
            <p>Current Time: {time.dateTime}</p>
            <p>Timezone: {time.timeZone}</p>
          </div>
        ) : (
          <p>No time data available</p>
        )}
      </div>
    </div>
  );
};

export default WeatherAndTime;