import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, TextInput } from 'react-native';
import Header from '../Header/header';
import Context from '../Context/context';

const HomeScreen = ({ navigation }) => {
  const initialData =[
    { id: '1',country:'South Africa', name: 'Johannesburg', image: require('../../assets/cities/jhb.jpg'), latitude: -26.2041, longitude: 28.0473, timeZone: 'Africa/Johannesburg', description: 'Known for its gold mining, Johannesburg is South Africa\'s largest city.', temperature: "", time: "" },
    { id: '2',country:'South Africa', name: 'Cape Town', image: require('../../assets/cities/cpt.jpg'), latitude: -33.9249, longitude: 18.4241, timeZone: 'Africa/Johannesburg', description: 'Famous for its Table Mountain and beautiful beaches, Cape Town is a vibrant cultural hub.', temperature: "", time: "" },
    { id: '3',country:'South Africa', name: 'Durban', image: require('../../assets/cities/dbn.jpg'), latitude: -29.8587, longitude: 31.0218, timeZone: 'Africa/Johannesburg', description: 'A coastal city known for its African, Indian, and colonial influences.', temperature: "", time: "" },
    { id: '4',country:'South Africa', name: 'Pretoria', image: require('../../assets/cities/pta.jpg'), latitude: -25.7479, longitude: 28.2293, timeZone: 'Africa/Johannesburg', description: 'One of South Africa\'s three capital cities, known for its jacaranda trees.', temperature: "", time: "" },
    { id: '5',country:'South Africa', name: 'Bloemfontein', image: require('../../assets/cities/bloem.jpg'), latitude: -29.0852, longitude: 26.1596, timeZone: 'Africa/Johannesburg', description: 'The judicial capital of South Africa, known for its rose gardens.', temperature: "", time: "" },
    { id: '6',country:'Canada', name: 'Montréal', image: require('../../assets/cities/montreal.jpg'), latitude: 45.5017, longitude: -73.5673, timeZone: 'America/Toronto', description: 'A vibrant city in Quebec, known for its French culture and festivals.', temperature: "", time: "" },
    { id: '7',country:'RD Congo', name: 'Kinshasa', image: require('../../assets/cities/kin.jpg'), latitude: -4.4419, longitude: 15.2663, timeZone: 'Africa/Kinshasa', description: 'The capital of the Democratic Republic of the Congo, located along the Congo River.', temperature: "", time: "" },
    { id: '8',country:'RD Congo', name: 'Kolwezi', image: require('../../assets/cities/klw.jpg'), latitude: -10.7144, longitude: 25.4667, timeZone: 'Africa/Lubumbashi', description: 'A mining city in the Democratic Republic of the Congo.', temperature: "", time: "" },
    { id: '9', country:'Canada',name: 'Ottawa', image: require('../../assets/cities/ottawa.jpg'), latitude: 45.4215, longitude: -75.6972, timeZone: 'America/Toronto', description: 'The capital city of Canada, known for its government buildings and museums.', temperature: "", time: "" },
    { id: '10',country:'RD Congo', name: 'Lubumbashi', image: require('../../assets/cities/lshi.jpg'), latitude: -11.6878, longitude: 27.5026, timeZone: 'Africa/Lubumbashi', description: 'The second largest city in the Democratic Republic of the Congo, a major mining area.', temperature: "", time: "" },
];

  const [data, setData] = useState(initialData);
  const [searchBar, setSearchBar] = useState('');
  
  useEffect(() => {
    const fetchDataForLocation = async (location) => {
      try {
        const timeResponse = await fetch(`https://timeapi.io/api/Time/current/zone?timeZone=${location.timeZone}`);
        const timeData = await timeResponse.json();

        const weatherResponse = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current_weather=true&timezone=${location.timeZone}`);
        const weatherData = await weatherResponse.json();

        if (timeData && weatherData.current_weather) {
          return {
            timeZone: timeData.timeZone,
            time: timeData.time,
            temperature: `${weatherData.current_weather.temperature}°C`
          };
        }
      } catch (error) {
        console.error('Error fetching data for location:', error);
      }
      return { timeZone: '', time: '', temperature: '' }; 
    };

    const updateAllLocations = async () => {
      const updatedData = await Promise.all(
        data.map(async (location) => {
          const newInfo = await fetchDataForLocation(location);
          return { ...location, ...newInfo };
        })
      );
      setData(updatedData);
    };

    updateAllLocations();
  }, []);

  const filteredDestinations = data.filter(item => 
    item.country.toLowerCase().includes(searchBar.toLowerCase()) ||
    item.name.toLowerCase().includes(searchBar.toLowerCase())
  );
  const handlePress = (item) => {
    navigation.navigate('Details', { item });
  };

  return (
    <>
    <Header />
    <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search your dream destination..."
          value={searchBar}
          onChangeText={text => setSearchBar(text)}
          placeholderTextColor="grey"
        />
      </View>
    <ScrollView style={styles.container}>
      
      {filteredDestinations.map((item) => (
        <TouchableOpacity key={item.id} style={styles.eventContainer} onPress={()=>handlePress(item)}>
          <Image source={item.image } style={styles.image} alt={item.country} />
          <View style={styles.textContainer}>
            <Text style={styles.title}>{item.name}</Text>
            <Text style={styles.subtitle}>{item.country}</Text>
            <Text style={styles.description}>{item.description}</Text>
            <Text style={styles.infoText}>Time Zone: {item.timeZone}</Text>
            <Text style={styles.infoText}>Time: {item.time}</Text>
            <Text style={styles.infoText}>Temperature: {item.temperature}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
    </>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#f8f9fa',
  },
  eventContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 15,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#e1e4e8',
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#2980b9',
    marginVertical: 8,
  },
  image: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  textContainer: {
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
    color: '#2c3e50',
  },
  location: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2980b9',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: '#34495e',
    marginBottom: 16,
    lineHeight: 24,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 16,
    paddingHorizontal: 15,
    paddingVertical: 8,
  },
  searchBar: {
    flex: 1,
    height: 40,
    fontSize: 16,
    color: '#333',
  },
  infoText: {
    fontSize: 16,
    color: '#34495e',
    marginBottom: 8,
  },
});



