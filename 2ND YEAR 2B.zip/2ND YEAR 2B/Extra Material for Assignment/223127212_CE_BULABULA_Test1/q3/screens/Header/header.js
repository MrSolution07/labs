import React from 'react';
import { View, Image, SafeAreaView, StyleSheet, Dimensions,Text } from 'react-native';

const { width } = Dimensions.get('window'); 

export default function Header() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Image source={require('../../assets/logo.png')} style={styles.logo} />
        <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Travel App</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    width: '100%',
    backgroundColor: '#f9f9f9',
  },
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    width: '100%',
    height:'auto'
  },
  logo: {
    width: width * 0.15, 
    height: 'auto',
    aspectRatio: 1, 
    resizeMode: 'contain',
  },
});