import { createStackNavigator } from "@react-navigation/stack";
import {NavigationContainer} from '@react-navigation/native';
import { useContext, useState } from "react";
import { View, Text } from 'react-native';
import React from 'react';
import Context from '../Context/context';
import HomeScreen from '../Home/HomeScreen';
import Details from "../DestinationDetails/details";

const Stack = createStackNavigator();
export default function AppNavigator() {
    const [destinationName, setDestinationName] = useState('');
    const [destinationDescription, setDestinationDescription] = useState('');
    const [currentWeather, setCurrentWeather] = useState('');
    const [currentTemp, setCurrentTemp] = useState('');
    const [time, setTime] = useState('');
    const [image, setImage] = useState('');

    const allInformation = [
        destinationName,setDestinationName,
        destinationDescription,setDestinationDescription,
        currentWeather,setCurrentWeather,
        currentTemp,setCurrentTemp,
        time,setTime,
        image,setImage,
    ]
  return (
    <Context.Provider value={allInformation}>
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Home">
            <Stack.Screen
                name="Home"
                component={HomeScreen} 
            />
            <Stack.Screen
                name="Details"
                component={Details} 
            />
            </Stack.Navigator>
        </NavigationContainer>
    </Context.Provider>
  )
}