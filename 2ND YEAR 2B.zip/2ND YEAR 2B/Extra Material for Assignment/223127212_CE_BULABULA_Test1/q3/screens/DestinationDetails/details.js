// screens/Details.js
import React, { useContext } from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import Context from '../Context/context';
import Header from '../Header/header'
const Details = ({ route }) => {
  const [destinationName,destinationDescription,currentWeather,currentTemp, time, image] = useContext(Context);
  const { item } = route.params; 

  if (!item) {
    return (
      <View style={styles.container}>
        <Text>No details available</Text>
      </View>
    );
  }
  return (
    <>
      <Header/>
      <ScrollView style={styles.container}>
        <Image source={item.image} style={styles.image} />
        <View style={styles.textContainer}>
          <Text style={styles.title}>{item.name}</Text>
          <Text style={styles.subtitle}>{item.country}</Text>
          <Text style={styles.description}>{item.description}</Text>
          <Text style={styles.infoText}>Time Zone: {item.timeZone}</Text>
          <Text style={styles.infoText}>Time: {item.time}</Text>
          <Text style={styles.infoText}>Temperature: {item.temperature}</Text>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  image: {
    width: '100%',
    height: 250,
  },
  textContainer: {
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2c3e50',
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#2980b9',
    marginVertical: 8,
  },
  description: {
    fontSize: 16,
    color: '#34495e',
    marginVertical: 12,
    lineHeight: 24,
  },
  infoText: {
    fontSize: 16,
    color: '#34495e',
    marginBottom: 8,
  },
});

export default Details;