import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import TouristInfoCards from './src/TouristInfoCards';
import Search from './src/Search';
import Bookings from './src/Bookings';


const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TouristInfoStack = () => {
  return (
    <Stack.Navigator initialRouteName="Tourist Info Cards">
      <Stack.Screen
        name="Tourist Info Cards"
        component={TouristInfoCards}
        options={{
          title: 'TouristInfoCards',
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: 'pink', 
          },
        }}
      />
    </Stack.Navigator>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarStyle: { backgroundColor: 'pink' }, 
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Tourist  Info  Cards') {
              iconName = focused ? 'home' : 'home-outline'; 
            } else if (route.name === 'Search') {
              iconName = focused ? 'search' : 'search-outline'; 
            } else if (route.name === 'Bookings') {
              iconName = focused ? 'book' : 'book-outline'; 
            }

           
            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen
          name="Tourist  Info  Cards"
          component={TouristInfoStack}
          options={{
            tabBarLabel: 'Tourist Cards',
            headerShown: false,
          }}
        />
        <Tab.Screen
          name="Search"
          component={Search}
          options={{
            tabBarLabel: 'Search',
            headerStyle: {
              backgroundColor: 'pink', 
            },
          }}
        />
        <Tab.Screen
          name="Bookings"
          component={Bookings}
          options={{
            tabBarLabel: 'Bookings',
            headerStyle: {
              backgroundColor: 'pink', 
            },
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default App;
