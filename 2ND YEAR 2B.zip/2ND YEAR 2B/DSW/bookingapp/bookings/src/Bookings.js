import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Table, Row, Rows } from 'react-native-table-component';
import data from './data.json'; 

const Bookings = () => {
  const [tableData, setTableData] = useState([]); 

  useEffect(() => {
   
    setTableData(data.bookings); 
  }, []);

  const tableHead = ['Title', 'First name', 'Surname', 'Room ID', 'Check-in date', 'Checkout date'];

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Bookings</Text>
      <Table borderStyle={{ borderWidth: 1, borderColor: '#c8e1ff' }}>
        <Row data={tableHead} style={styles.head} textStyle={styles.headText} />
        <Rows data={tableData.map(booking => Object.values(booking))} textStyle={styles.rowText} />
      </Table>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: 'pink' },
  header: { fontSize: 20, textAlign: 'center', marginBottom: 10 },
  head: { height: 40, backgroundColor: 'green' },
  headText: { margin: 6, textAlign: 'center', fontWeight: 'bold' },
  rowText: { margin: 6, textAlign: 'center' },
});

export default Bookings;
