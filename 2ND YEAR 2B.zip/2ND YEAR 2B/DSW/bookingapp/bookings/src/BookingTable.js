import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Table, Row, Rows } from 'react-native-table-component';
import data from './data.json';

function Bookings() {
  const [data, setData] = useState([]);

  useEffect(() => {
   
    const fetchData = async () => {
      try {
        const response = await fetch('data.json'); 
        const jsonData = await response.json();
        setData(jsonData.bookings); 
      } catch (error) {
        console.error('Error loading data:', error);
      }
    };

    fetchData();
  }, []);


  const tableData = data.map((item) => [
    item['Title'],
    item['First name'],
    item['Surname'],
    item['Room ID'], 
    item['Check-in date'],
    item['Check-out date'],
   
  ]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Bookings</Text>

     
      <Table borderStyle={{ borderWidth: 1 }}>
        <Row data={['Title', 'First name', 'Surname', 'Room ID', 'Check-in date', 'Check-out date']} style={styles.head} textStyle={styles.headText} />
        <Rows data={tableData} textStyle={styles.rowText} />
      </Table>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
  header: { fontSize: 20, textAlign: 'center', marginBottom: 10 },
  head: { height: 40, backgroundColor: '#f1f8ff' },
  headText: { margin: 6, textAlign: 'center', fontWeight: 'bold' },
  rowText: { margin: 6, textAlign: 'center' },
});

export default Bookings;
