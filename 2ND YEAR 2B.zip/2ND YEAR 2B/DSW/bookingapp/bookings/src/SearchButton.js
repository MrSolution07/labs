import React from 'react';
import { Button } from 'react-native';

const SearchButton = ({ onPress, buttonColor }) => {
  return (
    <Button
      title="Search"
      color={buttonColor} 
      onPress={onPress}
    />
  );
};

export default SearchButton;
