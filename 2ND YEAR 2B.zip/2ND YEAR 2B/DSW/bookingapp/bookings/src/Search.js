import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { Table, Row, Rows } from 'react-native-table-component';
import SearchButton from './SearchButton';

function Search() {
  const [nameText, setNameText] = useState('');
  const [idText, setIdText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  
 
  const data = [
    {
      "Title": "Mr",
      "FirstName": "Person1",
      "Surname": "Else",
      "Email": "Person1@else.com",
      "Room id": "1",
      "Check in date": "2-17-11-21",
      "Check out date": "2017-11-28"
    },
    {
      "Title": "Mr",
      "First name": "Person2",
      "Surname": "Else",
      "Email": "Person2@else.com",
      "Room id": "2",
      "Check in date": "2-17-11-21",
      "Check out date": "2017-11-28"
    },
    {
      "Title": "Mr",
      "First name": "Person3",
      "Surname": "Else",
      "Email": "Person3@else.com",
      "Room id": "3",
      "Check in date": "2-17-11-21",
      "Check out date": "2017-11-28"
    },
    {
      "Title": "Mr",
      "First name": "Person4",
      "Surname": "Else",
      "Email": "Person4@else.com",
      "Room id": "4",
      "Check in date": "2-17-11-21",
      "Check out date": "2017-11-28"
    },
    {
      "Title": "Mr",
      "First name": "Person5",
      "Surname": "Else",
      "Email": "Person5@else.com",
      "Room id": "5",
      "Check in date": "2-17-11-21",
      "Check out date": "2017-11-28"
    },
  ];

  const handleNameSearch = () => {   
    const trimmedNameText = nameText.trim().toLowerCase();
  
   
    const results = data.filter((item) => {
     
      const firstName = item['FirstName'] || item['First name'] || '';
      return firstName.toLowerCase().includes(trimmedNameText);
    });
  
    setSearchResults(results);
  };
  
  
  

  const handleIdSearch = () => {
   
    const results = data.filter((item) => item['Room id'] === idText);
    setSearchResults(results);
  };

 
  const tableData = searchResults.map((item) => [
    item['Title'],
    item['First name'] || item ['FirstName'],
    item['Surname'],
    item['Email'],
    item['Room id'],
    item['Check in date'],
    item['Check out date'],
    
  ]);

  return (
    <View style={styles.container}>
      

      <View>
        <TextInput style={styles.input}
          placeholder="Customer Name"
          value={nameText}
          onChangeText={(text) => setNameText(text)}
        />
        <SearchButton onPress={handleNameSearch} buttonColor="#ADD8E6"   />
      </View>

      <View>
        <TextInput style={styles.input}
          placeholder="Customer id"
          value={idText}
          onChangeText={(text) => setIdText(text)}
        />
        <SearchButton onPress={handleIdSearch} buttonColor="#ADD8E6"  />
      </View>

     
      <Table borderStyle={{ borderWidth: 1 ,}}>
        <Row data={['Title', 'First name', 'Surname', 'Email', 'Room id', 'Check in date', 'Check out date']} style={styles.head} textStyle={styles.text} />
        <Rows data={tableData} textStyle={styles.text} />
      </Table>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor:'pink',
   
  },
  head: { height: 40, backgroundColor: 'green', marginTop:40, },
  text: { margin: 6 },
  input:{
    marginBottom:20,
  }
});

export default Search;
