import React from 'react';
import { ScrollView, View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';

const TouristInfoCards = ({ navigation }) => {
  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={styles.header}>
        
        </View>

        <View style={[styles.card, styles.topImageContainer]}>
          <Image source={require('./kyotoJapan.jpg')} style={[styles.image, styles.roundedImage]} />
          <Text style={styles.text}>Kyoto, Japan</Text>
        </View>

        <View style={styles.card}>
          <Image source={require('./stPietersburgRussia.jpg')} style={[styles.image, styles.roundedImage]} />
          <Text style={styles.text}>St. Petersburg, Russia</Text>
        </View>

        <View style={styles.card}>
          <Image source={require('./singapore.jpg')} style={[styles.image, styles.roundedImage]} />
          <Text style={styles.text}>Singapore, Asia</Text>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Search')}
          >
            <Text style={styles.buttonText}>Search Bookings</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};





const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink', 
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    marginTop: 20, 
  },
  card: {
    marginBottom: 20,
  },
  topImageContainer: {
    marginTop: 20, 
  },
  image: {
    width: 210,
    height: 160,
  },
  roundedImage: {
    borderRadius: 40, 
  },
  text: {
    fontSize: 18,
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 20, 
  },
  button: {
    backgroundColor: '#ADD8E6', 
    paddingVertical: 15, 
    paddingHorizontal: 40, 
    borderRadius: 30, 
  },
  buttonText: {
    fontSize: 18,
    color: 'white', 
    textAlign: 'center',
  },
});

export default TouristInfoCards;
