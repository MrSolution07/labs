import logo from './logo.svg';
import './App.css';
import React,  {useState} from 'react';

function App() {

  const[count, setCounter] = useState(0);

  function Increase(){
    setCounter(count + 1)
  }

  function Decrease(){
    setCounter(count - 1)
  }
  function Reset(){
    setCounter(0)
  }
  

  return (
    <div className="App">
      <h1>Counter</h1>
      <h1>{count}</h1>
      <button className='btn' onClick={Increase}> Increase</button>
      <button className='btn' onClick={Decrease}> Decrease</button>
      <button className='btn' onClick={Reset}> reset</button>    
    </div>
  );
}

export default App;
