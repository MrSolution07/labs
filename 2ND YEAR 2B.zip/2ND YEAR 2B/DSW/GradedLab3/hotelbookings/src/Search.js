import React, {useState} from 'react';
import SearchButton from './SearchButton' ;


function Search() {   

    return(
        <View>
            <Text>Search Bookings</Text>
            <SearchButton/>
        </View>
    );
}

export default Search;