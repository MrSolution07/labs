import React from 'react';
import TestBookingData from './TestBookings.json';

function  JsonBookings () {

    const DisplayData = TestBookingData.map(
        (info) =>{
            return(
                
            )
        })
}