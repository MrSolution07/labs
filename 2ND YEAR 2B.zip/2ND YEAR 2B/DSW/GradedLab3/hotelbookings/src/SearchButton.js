import React, {seState} from "react";
import { Button, View ,Text} from "react-native";


function SearchButton ({onClick}){
    const [customerID , setCustomerId] = useState('');
    const [customerName , setCustomerName] = useState('');

    const handleIdSearch = () =>{


    };

    const handleNameSearch = () =>{
        

    };

    return(
        <View>
            <Text>Search Bookings</Text>
            <Button title="Search by ID" onPress={handleIdSearch}/>
            <Button title="Search by Name" onPress={handleNameSearch}/>            
        </View>
    );
}

export default SearchButton;