import React  from 'react';
import {View, Image , Text, StyleSheet} from 'react-native';


function TouristInfoCards (){

    return(
        <View style={styles.container}>

            <View style={styles.card}>
                
                <Image source={{ur:'city1.jpg'}} stye={styles.image}/>
                <Text>Kyoto,Japan</Text>
            </View>

            <View style={styles.card}>
                
                <Image source={{ur:'city2.jpg'}} stye={styles.image}/>
                <Text>Dubrovnik,Croatia</Text>
            </View>

            <View style={styles.card}>
                
                <Image source={{ur:'city3.jpg'}} stye={styles.image}/>
                <Text>St.Petersburg, Russia</Text>
            </View>




            
        </View>
    );
}

const styles = StyleSheet.create({
    container:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
    },
    card:{
        flex: 1,
        borderWidth:1,
        borderColor: '#ddd',
        borderRadius: 5,
        Margin:5,
        padding:10,
        alignItems:'center',
    },
    image:{
        width:100,
        height:100,
        marginBottom:5,
    },
    cityName:{
        fontWeight:'bold',
    },

    
});

export default TouristInfoCards;a