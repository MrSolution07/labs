import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Bookings from './Bookings';
import Search from './Search';
import TouristInfoCards from './TouristInfoCards';



export default function App() {
  return (
    <View style={styles.container}>
      <Search/>
      <TouristInfoCards/>
      <Bookings/>
     
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
