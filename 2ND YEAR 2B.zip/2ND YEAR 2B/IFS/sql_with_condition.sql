
CREATE DATABASE test_bank;
GO
USE test_bank;
GO

-- Create clients table
CREATE TABLE clients (
    ID INT PRIMARY KEY,
    First_Name VARCHAR(255),
    Last_Name VARCHAR(255),
    DOB DATE,
    Address_ VARCHAR(255),
    Age INT,
    Sex CHAR(1),
    Created_Time DATETIME,
    Contact_no VARCHAR(255),
    Work_no VARCHAR(255)
);
GO

-- Create branches table
CREATE TABLE branches (
    ID INT PRIMARY KEY,
    Name VARCHAR(45),
    Location VARCHAR(45),
    Manager VARCHAR(45)
);
GO

-- Create account_type table
CREATE TABLE account_type (
    ID INT PRIMARY KEY,
    Description_Type VARCHAR(500)
);
GO

-- Create account table
CREATE TABLE account (
    ID INT PRIMARY KEY,
    Balance_account INT,
    Status VARCHAR(45),
    Created_at DATETIME,
    Address_ VARCHAR(255),
    Client_ID INT,
    Account_type_ID INT,
    Branch_ID INT,
    FOREIGN KEY (Client_ID) REFERENCES clients(ID),
    FOREIGN KEY (Account_type_ID) REFERENCES account_type(ID),
    FOREIGN KEY (Branch_ID) REFERENCES branches(ID)
);
GO

-- Create transaction_type table
CREATE TABLE transaction_type (
    ID INT PRIMARY KEY,
    Transaction_type VARCHAR(45),
    Description VARCHAR(474),
    Transaction_fee INT
);
GO

-- Create transactions table
CREATE TABLE transactions (
    ID INT PRIMARY KEY IDENTITY(1,1),
    Amount_Transaction INT,
    Date_issued DATETIME,
    Deposit INT,
    Withdraw INT,
    Transfer INT,
    Total_Balance INT,
    Transaction_type_ID INT,
    Source_Account_ID INT,
    Destination_Account_ID INT,
    FOREIGN KEY (Transaction_type_ID) REFERENCES transaction_type(ID),
    FOREIGN KEY (Source_Account_ID) REFERENCES account(ID),
    FOREIGN KEY (Destination_Account_ID) REFERENCES account(ID)
);
GO

-- Insert values into account_type table
INSERT INTO account_type (ID, Description_Type) VALUES
(1, 'Savings'),
(2, 'Checking'),
(3, 'Business'),
(4, 'Joint');
GO

-- Insert values into branches table
INSERT INTO branches (ID, Name, Location, Manager) VALUES
(1, 'Downtown', 'Main St', 'John Doe'),
(2, 'Uptown', 'Elm St', 'Jane Smith'),
(3, 'Suburban', 'Oak St', 'Jim Brown'),
(4, 'Riverside', 'River Rd', 'Jake White'),
(5, 'Lakeside', 'Lake Ave', 'Julie Green'),
(6, 'Mountainview', 'Hill St', 'Jill Black'),
(7, 'Seaside', 'Beach Rd', 'Jack Grey'),
(8, 'Valley', 'Valley Rd', 'Jen Blue'),
(9, 'Country', 'Farm Rd', 'Jerry Orange'),
(10, 'City Center', 'Center St', 'Janet Purple');
GO

-- Insert values into transaction_type table
INSERT INTO transaction_type (ID, Transaction_type, Description, Transaction_fee) VALUES
(1, 'Deposit', 'Depositing money into account', 0),
(2, 'Withdrawal', 'Withdrawing money from account', 1),
(3, 'Transfer', 'Transferring money between accounts', 2);
GO

-- Insert values into clients table
INSERT INTO clients (ID, First_Name, Last_Name, DOB, Address_, Age, Sex, Created_Time, Contact_no, Work_no) VALUES
(1, 'ELLIS', 'KIRK', '1949-06-06', 'Rutherford Ln, Smithville, TX 78957, Berlin', NULL, 'F', '2023-08-15 09:30:00', '4915123456789', '4915798765432'),
(2, 'BELINDA', 'JOHNSON', '1996-01-14', 'Unnamed Road, Spearman, TX 79081, Munich', NULL, 'M', '2022-05-20 14:45:00', '4916387654321', '4915245678901'),
(3, 'JOELLE', 'BECK', '1989-04-15', '6121 Stan Roberts Sr Ave, TX 79934, Leipzig', NULL, 'M', '2021-11-10 18:15:00', '4916034567890', '4915567890123'),
(4, 'KEVIN', 'MCCABE', '1988-09-20', 'Goethestraße 25, Munich, 80333', NULL, 'F', '2020-03-05 11:00:00', '4915489012345', '4915956789012'),
(5, 'SCOTTY', 'ARMOUR', '1990-03-03', 'Ludwigstraße 10, Berlin, 10115', NULL, 'F', '2019-09-30 16:20:00', '4915843215678', '4916412345678');
GO

-- Insert values into account table
INSERT INTO account (ID, Balance_account, Status, Created_at, Address_, Client_ID, Account_type_ID, Branch_ID) VALUES
(1, 330, 'Active', '2023-08-15 09:30:00', 'Rutherford Ln, Smithville, TX 78957, Berlin', 1, 1, 1),
(2, 724, 'Active', '2023-07-01 10:30:00', 'Unnamed Road, Spearman, TX 79081, Munich', 1, 2, 3),
(3, 915, 'Active', '2023-07-05 14:15:00', '6121 Stan Roberts Sr Ave, TX 79934, Leipzig', 2, 1, 5),
(4, 6463, 'Active', '2023-07-12 09:00:00', 'Goethestraße 25, Munich, 80333', 3, 2, 7),
(5, 3832, 'Active', '2023-07-18 16:45:00', 'Ludwigstraße 10, Berlin, 10115', 4, 3, 9),
(6, 546, 'Active', '2023-07-22 12:20:00', 'Goethestraße 25, Munich, 80333', 3, 4, 10),
(7, 182, 'Active', '2023-08-15 09:30:00', 'Ludwigstraße 10, Berlin, 10115', 4, 2, 8),
(8, 731, 'Active', '2023-08-16 14:50:00', 'Rutherford Ln, Smithville, TX 78957, Berlin', 1, 1, 6);
GO

-- limit of 10 accounts per client
CREATE PROCEDURE CreateAccount
    @Balance_account INT,
    @Status VARCHAR(45),
    @Created_at DATETIME,
    @Address_ VARCHAR(255),
    @Client_ID INT,
    @Account_type_ID INT,
    @Branch_ID INT
AS
BEGIN
    DECLARE @account_count INT;

    -- Check if the client already has 10 accounts
    SELECT @account_count = COUNT(*)
    FROM account
    WHERE Client_ID = @Client_ID;

    IF @account_count < 10
    BEGIN
        -- Insert the new account
        INSERT INTO account (Balance_account, Status, Created_at, Address_, Client_ID, Account_type_ID, Branch_ID)
        VALUES (@Balance_account, @Status, @Created_at, @Address_, @Client_ID, @Account_type_ID, @Branch_ID);
    END
    ELSE
    BEGIN
        RAISERROR('Client already has 10 accounts', 16, 1);
    END
END;
GO

-- Create the stored procedure for handling transactions with fees
CREATE PROCEDURE PerformTransaction
    @Amount_Transaction INT,
    @Date_issued DATETIME,
    @Transaction_type_ID INT,
    @Source_Account_ID INT,
    @Destination_Account_ID INT
AS
BEGIN
    DECLARE @transaction_fee INT;
    DECLARE @new_balance_source INT;
    DECLARE @new_balance_destination INT;

    -- Get the transaction fee
    SELECT @transaction_fee = Transaction_fee
    FROM transaction_type
    WHERE ID = @Transaction_type_ID;

    -- Start a transaction
    BEGIN TRANSACTION;

    -- Update the source account
    UPDATE account
    SET Balance_account = Balance_account - @Amount_Transaction - @transaction_fee
    WHERE ID = @Source_Account_ID;

    -- Check if the update was successful and the account has enough funds
    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('Source account not found or insufficient funds', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    -- Get the new balance of the source account
    SELECT @new_balance_source = Balance_account
    FROM account
    WHERE ID = @Source_Account_ID;

    -- Update the destination account
    UPDATE account
    SET Balance_account = Balance_account + @Amount_Transaction
    WHERE ID = @Destination_Account_ID;

    -- Check if the destination account was updated successfully
    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('Destination account not found', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    -- Get the new balance of the destination account
    SELECT @new_balance_destination = Balance_account
    FROM account
    WHERE ID = @Destination_Account_ID;

    -- Insert the transaction record
    INSERT INTO transactions (Amount_Transaction, Date_issued, Deposit, Withdraw, Transfer, Total_Balance, Transaction_type_ID, Source_Account_ID, Destination_Account_ID)
    VALUES (@Amount_Transaction, @Date_issued,
            CASE WHEN @Transaction_type_ID = 1 THEN @Amount_Transaction ELSE 0 END,
            CASE WHEN @Transaction_type_ID = 2 THEN @Amount_Transaction ELSE 0 END,
            CASE WHEN @Transaction_type_ID = 3 THEN @Amount_Transaction ELSE 0 END,
            @new_balance_source,
            @Transaction_type_ID,
            @Source_Account_ID,
            @Destination_Account_ID);

    -- Commit the transaction
    COMMIT TRANSACTION;
END;
GO

SELECT * FROM clients;
SELECT * FROM branches;
SELECT * FROM account_type;
SELECT * FROM account;
SELECT * FROM transaction_type;
SELECT * FROM transactions;