CREATE DATABASE bank;
USE bank;

--clients table
CREATE TABLE clients (
    ID INT PRIMARY KEY,
    First_Name_ VARCHAR(255),
    Last_Name_ VARCHAR(255),
    DOB DATE,
    Address_ VARCHAR(255),
    Age INT,
    Sex VARCHAR(255),
    Created_Time DATETIME,
    Contact_no VARCHAR(255),
    Work_no VARCHAR(255)
);

--branches table
CREATE TABLE branches (
    ID INT PRIMARY KEY,
    Name_ VARCHAR(45),
    Location_ VARCHAR(45),
    Manager VARCHAR(45)
);

--account_type table
CREATE TABLE account_type (
    ID INT PRIMARY KEY,
    Description_Type VARCHAR(500)
);

--account table
CREATE TABLE account (
    ID INT PRIMARY KEY,
    Balance_account INT,
    Status_ VARCHAR(45),
    Created_at DATETIME,
    Address_ VARCHAR(255),
    Client_ID INT,
    Account_type INT,
    Branch_ID INT,
    FOREIGN KEY (Client_ID) REFERENCES clients(ID),
    FOREIGN KEY (Account_type) REFERENCES account_type(ID),
    FOREIGN KEY (Branch_ID) REFERENCES branches(ID)
);

--transaction_type table
CREATE TABLE transaction_type (
    ID INT PRIMARY KEY,
    Transaction_type VARCHAR(45),
    Description_ VARCHAR(474),
    Transaction_fee INT
);

--transactions table
CREATE TABLE transactions (
    ID INT PRIMARY KEY,
    Amount_Transaction INT,
    Date_issued DATETIME,
    Deposit INT,
    Withdraw INT,
    Transfer_ INT,
    Total_Balance INT,
    Transaction_type INT,
    Source_Account_ID INT,
    Destination_Account_ID INT,
    FOREIGN KEY (Transaction_type) REFERENCES transaction_type(ID),
    FOREIGN KEY (Source_Account_ID) REFERENCES account(ID),
    FOREIGN KEY (Destination_Account_ID) REFERENCES account(ID)
);


-- i inserted random values in the tables as the lecturer didn't provide them 

-- Insert values into account_type table
INSERT INTO account_type (ID, Description_Type) VALUES
(1, 'Savings'),
(2, 'Checking'),
(3, 'Business'),
(4, 'Joint');

-- Insert values into branches table
INSERT INTO branches (ID, Name_, Location_, Manager) VALUES
(1, 'Downtown', 'Main St', 'John Doe'),
(2, 'Uptown', 'Elm St', 'Jane Smith'),
(3, 'Suburban', 'Oak St', 'Jim Brown'),
(4, 'Riverside', 'River Rd', 'Jake White'),
(5, 'Lakeside', 'Lake Ave', 'Julie Green'),
(6, 'Mountainview', 'Hill St', 'Jill Black'),
(7, 'Seaside', 'Beach Rd', 'Jack Grey'),
(8, 'Valley', 'Valley Rd', 'Jen Blue'),
(9, 'Country', 'Farm Rd', 'Jerry Orange'),
(10, 'City Center', 'Center St', 'Janet Purple');

-- Insert values into transaction_type table
INSERT INTO transaction_type (ID, Transaction_type, Description_, Transaction_fee) VALUES
(1, 'Deposit', 'Depositing money into account', 0),
(2, 'Withdrawal', 'Withdrawing money from account', 1),
(3, 'Transfer', 'Transferring money between accounts', 2);


INSERT INTO clients (ID, First_Name_, Last_Name_, DOB, Address_, Age, Sex, Created_Time, Contact_no, Work_no) VALUES
(1, 'ELLIS', 'KIRK', '1949-06-06', 'Rutherford Ln, Smithville, TX 78957, Berlin', NULL, 'F', '2023-08-15 09:30:00', '4915123456789', '4915798765432'),
(2, 'BELINDA', 'JOHNSON', '1996-01-14', 'UnName_d Road, Spearman, TX 79081, Munich', NULL, 'M', '2022-05-20 14:45:00', '4916387654321', '4915245678901'),
(3, 'JOELLE', 'BECK', '1989-04-15', '6121 Stan Roberts Sr Ave, TX 79934, Leipzig', NULL, 'M', '2021-11-10 18:15:00', '4916034567890', '4915567890123'),
(4, 'KEVIN', 'MCCABE', '1988-09-20', 'Goethestraße 25, Munich, 80333', NULL, 'F', '2020-03-05 11:00:00', '4915489012345', '4915956789012'),
(5, 'SCOTTY', 'ARMOUR', '1990-03-03', 'Ludwigstraße 10, Berlin, 10115', NULL, 'F', '2019-09-30 16:20:00', '4915843215678', '4916412345678');


INSERT INTO account (ID, Balance_account, Status_, Created_at, Address_, Client_ID, Account_type, Branch_ID) VALUES
(1, 330, 'Active', '2023-08-15 09:30:00', 'Rutherford Ln, Smithville, TX 78957, Berlin', 1, 1, 1),
(2, 724, 'Active', '2023-07-01 10:30:00', 'UnName_d Road, Spearman, TX 79081, Munich', 1, 2, 3),
(3, 915, 'Active', '2023-07-05 14:15:00', '6121 Stan Roberts Sr Ave, TX 79934, Leipzig', 2, 1, 5),
(4, 6463, 'Active', '2023-07-12 09:00:00', 'Goethestraße 25, Munich, 80333', 3, 2, 7),
(5, 3832, 'Active', '2023-07-18 16:45:00', 'Ludwigstraße 10, Berlin, 10115', 4, 3, 9),
(6, 546, 'Active', '2023-07-22 12:20:00', 'Goethestraße 25, Munich, 80333', 3, 4, 10),
(7, 182, 'Active', '2023-08-15 09:30:00', 'Ludwigstraße 10, Berlin, 10115', 4, 2, 8),
(8, 731, 'Active', '2023-08-16 14:50:00', 'Rutherford Ln, Smithville, TX 78957, Berlin', 1, 1, 6);


SELECT * FROM clients;
SELECT * FROM account;

SELECT * FROM branches;
SELECT * FROM account_type;
SELECT * FROM transaction_type;

-- well, this last table is empty didnt require anything inside
SELECT * FROM transactions;

